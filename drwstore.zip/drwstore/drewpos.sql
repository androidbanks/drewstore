-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 01, 2024 at 04:37 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drewpos`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `comp_bra_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `branch_location` varchar(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `active` varchar(50) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `date_added` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comp_det`
--

CREATE TABLE `comp_det` (
  `comp_id` int(11) NOT NULL,
  `comp_code` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `business_type` varchar(255) NOT NULL,
  `business_address` varchar(255) NOT NULL,
  `business_email` varchar(255) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `industry` varchar(255) NOT NULL,
  `tin` varchar(20) NOT NULL,
  `active` varchar(50) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `date_added` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comp_det`
--

INSERT INTO `comp_det` (`comp_id`, `comp_code`, `company_name`, `business_type`, `business_address`, `business_email`, `phone_number`, `industry`, `tin`, `active`, `last_updated`, `date_added`) VALUES
(1, 'DRCOMP47766415016', 'Dream Gadgets', 'Retail', 'Katwe Kiguli', 'pc@gmail.com', '0779114800', 'Phones and accessories', '7837829000', 'Active', '2024-04-29 04:44:04', '2024-04-29 03:44:04'),
(2, 'DRCOMP394453717240', 'Kits Gadgets', 'Retail', 'Katwe Kiguli', 'bak@gmail.com', '0779114800', 'Phones and accessories gggg', '1234567890', 'Active', '2024-04-29 04:45:08', '2024-04-29 03:45:08'),
(3, 'DRCOMP935876961902', 'Kits Gadgets UG', 'Retail', 'Katwe Kiguli', 'pc500@gmail.com', '0779114800', 'Phones and accessories', '78378292928', 'Active', '2024-04-29 04:46:08', '2024-04-29 03:46:08'),
(4, '', '', '', '', '', '', '', '', 'Active', '2024-04-29 04:46:30', '2024-04-29 03:46:30'),
(5, 'DRCOMP619398888852', 'Dream Gadgets', 'Retail', 'Katwe Kiguli', 'bak00519@gmail.com', '0779114800', 'a', '88838929282', 'Active', '2024-04-29 21:55:36', '2024-04-29 20:55:36'),
(7, 'DRCOMP911564125757', 'Dream Gadgets', 'Retail', 'Katwe Kiguli', 'pc6780@gmail.com', '0779114800', 'Phones and accessories gggg', '88000000', 'Active', '2024-04-29 22:48:15', '2024-04-29 21:48:15'),
(8, 'DRCOMP473049839657', 'Dream Gadgets', 'Retail', 'Katwe Kiguli', 'bak1000@gmail.com', '0779114800', 'Phones and accessories gggg', '88838929282', 'Active', '2024-04-30 06:04:06', '2024-04-30 05:04:06'),
(9, 'DRCOMP895590640298', 'Dream Gadgets', 'Retail', 'Katwe Kiguli', 'bak1900@gmail.com', '0779114800', 'Phones and accessories', '88000000', 'Active', '2024-05-01 01:03:55', '2024-05-01 00:03:55');

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

CREATE TABLE `otps` (
  `id` int(11) NOT NULL,
  `comp_code` varchar(20) NOT NULL,
  `otp_code` varchar(10) NOT NULL,
  `otp_Status` varchar(20) NOT NULL,
  `freq` varchar(20) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `otps`
--

INSERT INTO `otps` (`id`, `comp_code`, `otp_code`, `otp_Status`, `freq`, `date_added`) VALUES
(1, 'DRCOMP394453717240', '910355', 'Active', 'First_time', '2024-04-29 03:45:08'),
(2, 'DRCOMP935876961902', '651180', 'Active', 'First_time', '2024-04-29 03:46:08'),
(3, '', '744688', 'Active', 'First_time', '2024-04-29 03:46:30'),
(4, 'DRCOMP619398888852', '106561', 'Active', 'First_time', '2024-04-29 20:55:36'),
(5, 'DRCOMP911564125757', '858198', 'Active', 'First_time', '2024-04-29 21:48:15'),
(6, 'DRCOMP473049839657', '634265', 'Active', 'First_time', '2024-04-30 05:04:06'),
(7, 'DRCOMP895590640298', '168083', 'Active', 'First_time', '2024-05-01 00:03:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_code` varchar(50) NOT NULL,
  `comp_code` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `role` varchar(15) NOT NULL,
  `active` varchar(10) DEFAULT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `date_added` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_code`, `comp_code`, `username`, `password`, `full_name`, `phone_number`, `address`, `role`, `active`, `last_login`, `last_updated`, `date_added`) VALUES
(1, 'DRSU864792093230', '', 'pc@gmail.com', 'admin', 'Kizito Andrew Bakaawa', '0779114800', 'Katwe Kiguli', 'Super User', 'Active', '2024-04-29 04:44:04', '2024-04-29 04:44:04', '2024-04-29 03:44:04'),
(3, 'DRSU32043644787', '', 'bak@gmail.com', 'admin', 'Kizito Andrew Bakaawa', '0779114800', 'Katwe Kiguli', 'Super User', 'Active', '2024-04-29 04:45:08', '2024-04-29 04:45:08', '2024-04-29 03:45:08'),
(4, 'DRSU152382245722', '', 'pc500@gmail.com', 'admin', 'Kizito Andrew Bakaawa', '0779114800', 'Katwe Kiguli', 'Super User', 'Active', '2024-04-29 04:46:08', '2024-04-29 04:46:08', '2024-04-29 03:46:08'),
(5, '', '', '', '', '', '', '', 'Super User', 'Active', '2024-04-29 04:46:30', '2024-04-29 04:46:30', '2024-04-29 03:46:30'),
(6, 'DRSU720573147359', '', 'bak00519@gmail.com', 'admin', 'Kizito Andrew Bakaawa', '0779114800', 'Katwe Kiguli', 'Super User', 'Active', '2024-04-29 21:55:36', '2024-04-29 21:55:36', '2024-04-29 20:55:36'),
(7, 'DRSU270912529736', '', 'pc6780@gmail.com', 'admin', 'Kizito Andrew Bakaawa', '0779114800', 'Katwe Kiguli', 'Super User', 'Active', '2024-04-29 22:48:15', '2024-04-29 22:48:15', '2024-04-29 21:48:15'),
(8, 'DRSU360097622046', 'DRCOMP473049839657', 'bak1000@gmail.com', 'admin', 'Kizito Andrew Bakaawa', '0779114800', 'Katwe Kiguli', 'Super User', 'Active', '2024-04-30 06:04:06', '2024-04-30 06:04:06', '2024-04-30 05:04:06'),
(9, 'DRSU421753257619', 'DRCOMP895590640298', 'bak1900@gmail.com', 'admin', 'Kizito Andrew Bakaawa', '0779114800', 'Katwe Kiguli', 'Super User', 'Active', '2024-05-01 01:03:55', '2024-05-01 01:03:55', '2024-05-01 00:03:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`comp_bra_id`);

--
-- Indexes for table `comp_det`
--
ALTER TABLE `comp_det`
  ADD PRIMARY KEY (`comp_id`),
  ADD UNIQUE KEY `comp_code` (`comp_code`);

--
-- Indexes for table `otps`
--
ALTER TABLE `otps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `comp_bra_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comp_det`
--
ALTER TABLE `comp_det`
  MODIFY `comp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `otps`
--
ALTER TABLE `otps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
