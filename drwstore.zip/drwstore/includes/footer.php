<footer class="main-footer no-print">
    <strong>Copyright &copy; <?php echo date('Y');?> <a href="https://cbspewosacoop.com.io">DREWPOS</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>V</b>1.6.0
    </div>
  </footer>