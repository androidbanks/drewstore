<?php
session_start();

if (empty($_SESSION['mem_id'])) {
    // Log debug information
    error_log('Session variable mem_id is missing or empty');
    header("Location: ../index.php");
    exit();
}
?>