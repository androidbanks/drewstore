<?php 
	//Connect to mysql server
	//$conn = mysqli_connect('localhost','cbspewos_drewpos',"Sbc@72226",'cbspewos_sale');
	$conn = mysqli_connect('localhost','root',"",'invoice_db');
	if(!$conn) {
		die('Failed to connect to server: ' . mysqli_error());
	}
	
?>