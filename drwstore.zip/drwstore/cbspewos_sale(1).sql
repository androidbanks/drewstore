-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 23, 2024 at 09:35 PM
-- Server version: 5.7.23-23
-- PHP Version: 8.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cbspewos_sale`
--

-- --------------------------------------------------------

--
-- Table structure for table `comp_acc`
--

CREATE TABLE `comp_acc` (
  `acc_id` int(11) NOT NULL,
  `acc_code` varchar(50) NOT NULL,
  `acc_name` varchar(100) NOT NULL,
  `acc_type` varchar(50) NOT NULL,
  `acc_number` varchar(20) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `branch_name` varchar(100) NOT NULL,
  `balance` decimal(15,2) DEFAULT '0.00',
  `currency` varchar(3) DEFAULT 'UGX',
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comp_acc`
--

INSERT INTO `comp_acc` (`acc_id`, `acc_code`, `acc_name`, `acc_type`, `acc_number`, `bank_name`, `branch_name`, `balance`, `currency`, `date_added`) VALUES
(1, 'ACC001', 'Mobile Money Account', 'Savings', '1234567890', 'Bank A', 'Main Branch', 5000.00, 'UGX', '2024-06-26 07:17:43'),
(2, 'ACC002', 'Checking Account', 'Checking', '9876543210', 'Bank B', 'Downtown Branch', 10000.00, 'UGX', '2024-06-26 07:17:43'),
(3, 'ACC003', 'Investment Account', 'Investment', '5678901234', 'Bank C', 'City Center Branch', 25000.00, 'UGX', '2024-06-26 07:17:43'),
(4, 'ACC004', 'Salary Account', 'Salary', '2345678901', 'Bank D', 'Suburb Branch', 15000.00, 'UGX', '2024-06-26 07:17:43'),
(5, 'ACC005', 'Business Account', 'Business', '8765432109', 'Bank E', 'Industrial Area Branch', 35000.00, 'UGX', '2024-06-26 07:17:43');

-- --------------------------------------------------------

--
-- Table structure for table `comp_bra`
--

CREATE TABLE `comp_bra` (
  `comp_bra_id` int(11) NOT NULL,
  `bra_code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `head` varchar(50) NOT NULL,
  `note` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comp_bra`
--

INSERT INTO `comp_bra` (`comp_bra_id`, `bra_code`, `name`, `address`, `phone`, `head`, `note`, `date_added`) VALUES
(1, 'DRBRA00001', 'Ndeeba ', 'Ndeeba Lubaga', '078967720', 'Nakanwagi Hallen', '', '2023-06-28 20:49:16'),
(2, 'DRBRA00001', 'Katwe ', 'Katwe Kampala', '078967720', 'Kato Paul', '', '2023-06-28 20:50:11'),
(3, 'DRCOMP5994', 'Namasuba', 'Namasuba Ndejje', '078967567', 'Kafeero', 'Jiggle ', '2023-06-29 04:28:49'),
(4, 'DRCOMP5994', 'Namasuba', 'Namasuba Ndejje', '078967567', 'Kafeero', 'Jiggle ', '2023-06-29 04:31:47'),
(5, 'DRCOMP5994', 'Namasuba', 'Namasuba Ndejje', '078967567', 'Kafeero', 'Jiggle ', '2023-06-29 04:31:54'),
(6, 'DRCOMP5994', 'Namasuba', 'Namasuba Ndejje', '078967567', 'Kafeero', 'Jiggle ', '2023-06-29 04:34:01');

-- --------------------------------------------------------

--
-- Table structure for table `comp_det`
--

CREATE TABLE `comp_det` (
  `comp_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phone1` varchar(50) NOT NULL,
  `phone2` varchar(50) NOT NULL,
  `website` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comp_det`
--

INSERT INTO `comp_det` (`comp_id`, `code`, `name`, `address`, `phone1`, `phone2`, `website`, `email`, `description`, `date_added`) VALUES
(3, 'DRCOMP9670', 'Hijab Point UG', 'Frech plaza Shop 234', '0779114800', '0702050663', 'hijabpointug.com', 'info@hijabpointug.com', '', '2023-06-28 12:33:45');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cust_id` int(11) NOT NULL,
  `cust_code` varchar(50) NOT NULL,
  `cust_name` varchar(50) NOT NULL,
  `cust_email` varchar(50) NOT NULL,
  `cust_phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exp`
--

CREATE TABLE `exp` (
  `exp_id` int(11) NOT NULL,
  `expcat_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `exp_name` varchar(50) NOT NULL,
  `vendor` varchar(50) NOT NULL,
  `inv_no` varchar(50) NOT NULL,
  `amount` bigint(255) NOT NULL,
  `amount_paid` bigint(255) NOT NULL,
  `due_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `balance` bigint(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `note` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exp`
--

INSERT INTO `exp` (`exp_id`, `expcat_id`, `code`, `exp_name`, `vendor`, `inv_no`, `amount`, `amount_paid`, `due_date`, `balance`, `status`, `note`, `date_added`) VALUES
(1, 4, 'DRINV27286', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 13070000, 6000000, '2022-01-29 00:39:21', 7070000, 'pending', 'product Purchased', '2022-01-29 00:36:47'),
(2, 4, 'DRINV87795', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 2200000, 2200000, '2022-01-29 00:52:29', 0, 'paid', 'product Purchased', '2022-01-29 00:59:25'),
(3, 4, 'DRINV8749', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 2400000, 2000000, '2022-04-02 21:00:00', 400000, 'pending', 'product Purchased', '2022-02-05 13:02:54'),
(4, 4, 'DRINV79380', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 2490000, 2490000, '2022-02-05 13:31:39', 0, 'paid', 'product Purchased', '2022-02-05 13:35:12'),
(5, 4, 'DRINV11293', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 2490000, 2490000, '2022-02-05 13:31:39', 0, 'paid', 'product Purchased', '2022-02-05 13:41:45'),
(6, 4, 'DRINV16247', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 2490000, 2490000, '2022-02-05 13:31:39', 0, 'paid', 'product Purchased', '2022-02-05 13:42:49'),
(7, 4, 'DRINV10195', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 2490000, 2490000, '2022-02-05 13:31:39', 0, 'paid', 'product Purchased', '2022-02-05 13:47:36'),
(8, 4, 'DRINV25776', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 2200000, 2200000, '2022-02-06 00:21:59', 0, 'paid', 'product Purchased', '2022-02-06 00:44:54'),
(9, 4, 'DRINV28490', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 1950000, 1950000, '2022-02-06 01:19:17', 0, 'paid', 'product Purchased', '2022-02-06 01:21:19'),
(10, 4, 'DRINV40021', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 1950000, 1950000, '2022-02-06 01:19:17', 0, 'paid', 'product Purchased', '2022-02-06 01:21:26'),
(11, 4, 'DRINV22092', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 1950000, 1950000, '2022-02-06 01:19:17', 0, 'paid', 'product Purchased', '2022-02-06 01:21:34'),
(12, 4, 'DRINV93242', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 1650000, 1650000, '2022-02-06 01:25:48', 0, 'paid', 'product Purchased', '2022-02-06 01:30:54'),
(13, 4, 'DRINV91642', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 1650000, 1650000, '2022-02-06 01:25:48', 0, 'paid', 'product Purchased', '2022-02-06 01:31:21'),
(14, 4, 'DRINV81100', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 1650000, 1650000, '2022-02-06 01:25:48', 0, 'paid', 'product Purchased', '2022-02-06 01:32:49'),
(15, 4, 'DRINV21548', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 01:49:55'),
(16, 4, 'DRINV79324', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 01:52:19'),
(17, 4, 'DRINV99604', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 01:53:12'),
(18, 4, 'DRINV52734', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 01:53:49'),
(19, 4, 'DRINV60393', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 01:55:31'),
(20, 4, 'DRINV88593', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 02:04:00'),
(21, 4, 'DRINV94786', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 02:11:06'),
(22, 4, 'DRINV97831', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:06:42'),
(23, 4, 'DRINV29412', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:07:00'),
(24, 4, 'DRINV38034', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:12:43'),
(25, 4, 'DRINV24656', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:13:01'),
(26, 4, 'DRINV8187', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:15:33'),
(27, 4, 'DRINV67395', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:16:33'),
(28, 4, 'DRINV56953', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:28:31'),
(29, 4, 'DRINV94013', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:28:53'),
(30, 4, 'DRINV99903', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:29:45'),
(31, 4, 'DRINV6348', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:31:17'),
(32, 4, 'DRINV23089', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:33:10'),
(33, 4, 'DRINV41661', 'Cost of Goods Sold', 'Drew Inc Uganda', 'HS-09909', 500000, 500000, '2022-02-06 01:48:53', 0, 'paid', 'product Purchased', '2022-02-06 03:39:02'),
(34, 4, 'DRINV13270', 'Cost of Goods Sold', 'holy steps', 'HS-09909', 1726000, 1726000, '2022-02-06 03:41:22', 0, 'paid', 'product Purchased', '2022-02-06 03:43:35'),
(35, 4, 'DRINV39173', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 380000, 380000, '2022-02-06 04:51:43', 0, 'paid', 'product Purchased', '2022-02-06 04:52:58'),
(36, 4, 'DRINV58509', 'Cost of Goods Sold', 'Kampala Phones ', 't-456554', 5000, 5000, '2022-02-06 04:54:24', 0, 'paid', 'product Purchased', '2022-02-06 04:55:15'),
(37, 4, 'DRINV75166', 'Cost of Goods Sold', 'holy steps', 'DR-45676', 380000, 380000, '2022-02-06 05:04:56', 0, 'paid', 'product Purchased', '2022-02-06 05:05:32'),
(38, 4, 'DRINV19435', 'Cost of Goods Sold', 'holy steps', 'DR-45676', 380000, 380000, '2022-02-06 05:04:56', 0, 'paid', 'product Purchased', '2022-02-06 05:07:16'),
(39, 4, 'DRINV940', 'Cost of Goods Sold', 'holy steps', 'DR-45676', 380000, 380000, '2022-02-06 05:04:56', 0, 'paid', 'product Purchased', '2022-02-06 05:08:00'),
(40, 4, 'DRINV78507', 'Cost of Goods Sold', 'holy steps', 'DR-45676', 380000, 380000, '2022-02-06 05:04:56', 0, 'paid', 'product Purchased', '2022-02-06 05:08:18'),
(41, 4, 'DRINV39441', 'Cost of Goods Sold', 'holy steps', 'DR-45676', 380000, 380000, '2022-02-06 05:04:56', 0, 'paid', 'product Purchased', '2022-02-06 05:09:00'),
(42, 4, 'DRINV61164', 'Cost of Goods Sold', 'holy steps', 'DR-45676', 380000, 380000, '2022-02-06 05:04:56', 0, 'paid', 'product Purchased', '2022-02-06 05:09:25'),
(43, 4, 'DRINV99213', 'Cost of Goods Sold', 'holy steps', 'DR-45676', 404000, 404000, '2022-02-06 05:04:56', 0, 'paid', 'product Purchased', '2022-02-06 05:12:41'),
(44, 4, 'DRINV51585', 'Cost of Goods Sold', 'holy steps', 'DR-45676', 100000, 100000, '2022-02-06 05:13:08', 0, 'paid', 'product Purchased', '2022-02-06 05:13:35'),
(45, 4, 'DRINV9194', 'Cost of Goods Sold', 'holy steps', 'HS-09909', 120000, 120000, '2022-02-06 05:16:23', 0, 'paid', 'product Purchased', '2022-02-06 05:17:39'),
(46, 4, 'DRINV33606', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 1900000, 1900000, '2022-02-06 05:18:07', 0, 'paid', 'product Purchased', '2022-02-06 05:18:39'),
(47, 4, 'DRINV47949', 'Cost of Goods Sold', 'Muza Investiments ', 'DR-45676', 60000, 60000, '2022-02-06 05:19:16', 0, 'paid', 'product Purchased', '2022-02-06 05:19:44'),
(48, 4, 'DRINV71221', 'Cost of Goods Sold', 'holy steps', 'DR-45679', 250000, 250000, '2022-02-06 05:23:02', 0, 'paid', 'product Purchased', '2022-02-06 05:23:37'),
(49, 4, 'DRINV9802', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:24:45'),
(50, 4, 'DRINV57183', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:34:31'),
(51, 4, 'DRINV63149', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:35:52'),
(52, 4, 'DRINV33661', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:38:22'),
(53, 4, 'DRINV97498', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:40:08'),
(54, 4, 'DRINV14744', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:42:38'),
(55, 4, 'DRINV48466', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:42:54'),
(56, 4, 'DRINV14177', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:44:00'),
(57, 4, 'DRINV41442', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:44:57'),
(58, 4, 'DRINV22995', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:45:36'),
(59, 4, 'DRINV8688', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:46:37'),
(60, 4, 'DRINV3523', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:52:21'),
(61, 4, 'DRINV48354', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:54:20'),
(62, 4, 'DRINV30348', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 06:56:06'),
(63, 4, 'DRINV76163', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:01:18'),
(64, 4, 'DRINV24403', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:01:34'),
(65, 4, 'DRINV6972', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:01:53'),
(66, 4, 'DRINV86010', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:03:10'),
(67, 4, 'DRINV19546', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:03:17'),
(68, 4, 'DRINV58230', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:04:14'),
(69, 4, 'DRINV31843', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:05:05'),
(70, 4, 'DRINV20101', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:05:19'),
(71, 4, 'DRINV5957', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:05:39'),
(72, 4, 'DRINV17095', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:06:52'),
(73, 4, 'DRINV99387', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:07:41'),
(74, 4, 'DRINV14482', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:08:10'),
(75, 4, 'DRINV55477', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:09:21'),
(76, 4, 'DRINV73156', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:09:44'),
(77, 4, 'DRINV30431', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:12:25'),
(78, 4, 'DRINV89508', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:12:39'),
(79, 4, 'DRINV60382', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:12:52'),
(80, 4, 'DRINV4416', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:13:07'),
(81, 4, 'DRINV72185', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:21:45'),
(82, 4, 'DRINV44091', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:21:48'),
(83, 4, 'DRINV68541', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:21:52'),
(84, 4, 'DRINV22458', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:21:53'),
(85, 4, 'DRINV84238', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:22:03'),
(86, 4, 'DRINV95190', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:22:19'),
(87, 4, 'DRINV41559', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:22:50'),
(88, 4, 'DRINV1919', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:23:18'),
(89, 4, 'DRINV80402', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:24:05'),
(90, 4, 'DRINV11725', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:25:20'),
(91, 4, 'DRINV17061', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:25:44'),
(92, 4, 'DRINV86654', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:26:12'),
(93, 4, 'DRINV75518', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:26:52'),
(94, 4, 'DRINV69882', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:27:41'),
(95, 4, 'DRINV9114', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:28:16'),
(96, 4, 'DRINV43672', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:28:27'),
(97, 4, 'DRINV14370', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:30:55'),
(98, 4, 'DRINV78802', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:33:35'),
(99, 4, 'DRINV83338', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:34:55'),
(100, 4, 'DRINV47809', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:45:12'),
(101, 4, 'DRINV7290', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:46:00'),
(102, 4, 'DRINV27019', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:46:32'),
(103, 4, 'DRINV79871', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:46:52'),
(104, 4, 'DRINV97628', 'Cost of Goods Sold', 'Katumwa', 't-456554', 150000, 150000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:48:24'),
(105, 4, 'DRINV53270', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:51:00'),
(106, 4, 'DRINV64740', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:52:08'),
(107, 4, 'DRINV64083', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:55:14'),
(108, 4, 'DRINV9599', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:56:11'),
(109, 4, 'DRINV81937', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 07:56:49'),
(110, 4, 'DRINV96217', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:06:39'),
(111, 4, 'DRINV66849', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:06:46'),
(112, 4, 'DRINV94822', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:08:07'),
(113, 4, 'DRINV46523', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:08:22'),
(114, 4, 'DRINV13061', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:08:53'),
(115, 4, 'DRINV87490', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:09:46'),
(116, 4, 'DRINV34645', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:10:01'),
(117, 4, 'DRINV6402', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:10:50'),
(118, 4, 'DRINV1212', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:11:09'),
(119, 4, 'DRINV10953', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:12:17'),
(120, 4, 'DRINV20552', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:13:08'),
(121, 4, 'DRINV37858', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:14:16'),
(122, 4, 'DRINV30466', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:15:40'),
(123, 4, 'DRINV25270', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:16:25'),
(124, 4, 'DRINV13350', 'Cost of Goods Sold', 'Katumwa', 't-456554', 930000, 930000, '2022-02-06 06:22:47', 0, 'paid', 'product Purchased', '2022-02-06 08:17:19'),
(125, 4, 'DRINV55405', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:35:44'),
(126, 4, 'DRINV44799', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:36:11'),
(127, 4, 'DRINV81835', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:36:43'),
(128, 4, 'DRINV55720', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:37:12'),
(129, 4, 'DRINV41202', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:37:21'),
(130, 4, 'DRINV83766', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:39:05'),
(131, 4, 'DRINV99151', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:41:50'),
(132, 4, 'DRINV77784', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:42:40'),
(133, 4, 'DRINV64766', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:43:02'),
(134, 4, 'DRINV52693', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:43:24'),
(135, 4, 'DRINV79408', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:44:02'),
(136, 4, 'DRINV37410', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:44:56'),
(137, 4, 'DRINV35515', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:49:18'),
(138, 4, 'DRINV93895', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-07 19:56:38'),
(139, 4, 'DRINV4388', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:31:37'),
(140, 4, 'DRINV40851', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:32:37'),
(141, 4, 'DRINV25658', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:33:40'),
(142, 4, 'DRINV47719', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:34:25'),
(143, 4, 'DRINV28120', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:34:49'),
(144, 4, 'DRINV71419', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:35:08'),
(145, 4, 'DRINV25511', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:39:30'),
(146, 4, 'DRINV55309', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:40:04'),
(147, 4, 'DRINV76690', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:42:19'),
(148, 4, 'DRINV30598', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:42:47'),
(149, 4, 'DRINV19845', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:44:42'),
(150, 4, 'DRINV7538', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:46:09'),
(151, 4, 'DRINV46845', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:46:18'),
(152, 4, 'DRINV27978', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:46:47'),
(153, 4, 'DRINV21782', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:47:09'),
(154, 4, 'DRINV47605', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:56:43'),
(155, 4, 'DRINV42319', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:57:35'),
(156, 4, 'DRINV23173', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 03:57:45'),
(157, 4, 'DRINV42891', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:00:07'),
(158, 4, 'DRINV52499', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:00:44'),
(159, 4, 'DRINV83202', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:01:29'),
(160, 4, 'DRINV7401', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:01:53'),
(161, 4, 'DRINV14652', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:02:40'),
(162, 4, 'DRINV12974', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:04:34'),
(163, 4, 'DRINV7322', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:06:31'),
(164, 4, 'DRINV11596', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:09:17'),
(165, 4, 'DRINV64020', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:09:55'),
(166, 4, 'DRINV41490', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:10:17'),
(167, 4, 'DRINV19829', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:10:50'),
(168, 4, 'DRINV41360', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:11:24'),
(169, 4, 'DRINV83974', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:12:48'),
(170, 4, 'DRINV68143', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:14:51'),
(171, 4, 'DRINV22894', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:15:17'),
(172, 4, 'DRINV20824', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:18:06'),
(173, 4, 'DRINV44287', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:18:31'),
(174, 4, 'DRINV11313', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:19:56'),
(175, 4, 'DRINV28704', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:20:36'),
(176, 4, 'DRINV72177', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:22:08'),
(177, 4, 'DRINV9916', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:24:28'),
(178, 4, 'DRINV31626', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:24:59'),
(179, 4, 'DRINV2084', 'Cost of Goods Sold', 'holy steps', 'DRI-00032', 2100000, 2100000, '2022-02-07 19:34:18', 0, 'paid', 'product Purchased', '2022-02-08 04:32:31'),
(180, 4, 'DRINV62050', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 14:50:22'),
(181, 4, 'DRINV65996', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 14:51:19'),
(182, 4, 'DRINV85483', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 14:51:27'),
(183, 4, 'DRINV32913', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 14:54:13'),
(184, 4, 'DRINV50471', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 14:57:35'),
(185, 4, 'DRINV57552', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 14:59:53'),
(186, 4, 'DRINV73531', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:00:17'),
(187, 4, 'DRINV94069', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:07:39'),
(188, 4, 'DRINV99904', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:07:55'),
(189, 4, 'DRINV74935', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:09:38'),
(190, 4, 'DRINV41502', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:10:08'),
(191, 4, 'DRINV9401', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:12:48'),
(192, 4, 'DRINV86211', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:13:11'),
(193, 4, 'DRINV84720', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:13:29'),
(194, 4, 'DRINV99266', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:13:45'),
(195, 4, 'DRINV98888', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:14:07'),
(196, 4, 'DRINV75550', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:14:10'),
(197, 4, 'DRINV41633', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:14:44'),
(198, 4, 'DRINV86564', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:15:10'),
(199, 4, 'DRINV62063', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:15:40'),
(200, 4, 'DRINV22274', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1130000, 1130000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:24:10'),
(201, 4, 'DRINV11669', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:25:21'),
(202, 4, 'DRINV82643', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:26:32'),
(203, 4, 'DRINV32035', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:28:52'),
(204, 4, 'DRINV53348', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:29:45'),
(205, 4, 'DRINV97983', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:30:39'),
(206, 4, 'DRINV95751', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:31:10'),
(207, 4, 'DRINV83402', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:31:42'),
(208, 4, 'DRINV48270', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:32:17'),
(209, 4, 'DRINV45314', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:36:10'),
(210, 4, 'DRINV13164', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:37:20'),
(211, 4, 'DRINV11450', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:38:27'),
(212, 4, 'DRINV74919', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:39:39'),
(213, 4, 'DRINV90915', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:40:03'),
(214, 4, 'DRINV83993', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:41:12'),
(215, 4, 'DRINV67996', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:41:48'),
(216, 4, 'DRINV867', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:42:01'),
(217, 4, 'DRINV13825', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:44:00'),
(218, 4, 'DRINV79983', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:44:21'),
(219, 4, 'DRINV39708', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:44:32'),
(220, 4, 'DRINV82999', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:45:15'),
(221, 4, 'DRINV5004', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:46:17'),
(222, 4, 'DRINV69329', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:46:30'),
(223, 4, 'DRINV94364', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:47:45'),
(224, 4, 'DRINV28872', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:56:59'),
(225, 4, 'DRINV31715', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:57:40'),
(226, 4, 'DRINV54410', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:58:09'),
(227, 4, 'DRINV56409', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:58:45'),
(228, 4, 'DRINV26817', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 15:59:06'),
(229, 4, 'DRINV60667', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:00:03'),
(230, 4, 'DRINV3271', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:00:42'),
(231, 4, 'DRINV26243', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:01:13'),
(232, 4, 'DRINV21729', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:03:51'),
(233, 4, 'DRINV98058', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:04:41'),
(234, 4, 'DRINV99444', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:05:45'),
(235, 4, 'DRINV24495', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:06:20'),
(236, 4, 'DRINV38152', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:06:34'),
(237, 4, 'DRINV76353', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:06:54'),
(238, 4, 'DRINV13121', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:10:41'),
(239, 4, 'DRINV51201', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:11:13'),
(240, 4, 'DRINV38931', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:11:25'),
(241, 4, 'DRINV50651', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:11:50'),
(242, 4, 'DRINV87551', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:12:05'),
(243, 4, 'DRINV53889', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:12:41'),
(244, 4, 'DRINV36581', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:14:29'),
(245, 4, 'DRINV86557', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:17:17'),
(246, 4, 'DRINV71470', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:17:56'),
(247, 4, 'DRINV56231', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:18:33'),
(248, 4, 'DRINV65976', 'Cost of Goods Sold', 'Drew Inc Uganda', '7809', 1930000, 1930000, '2022-02-08 14:42:00', 0, 'paid', 'product Purchased', '2022-02-08 16:19:06'),
(249, 4, 'DRINV59575', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 00:56:49'),
(250, 4, 'DRINV66829', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 00:59:58'),
(251, 4, 'DRINV83102', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:01:53'),
(252, 4, 'DRINV20164', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:10:38'),
(253, 4, 'DRINV2917', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:12:35'),
(254, 4, 'DRINV18519', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:12:55'),
(255, 4, 'DRINV50778', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:13:11'),
(256, 4, 'DRINV26347', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:18:07'),
(257, 4, 'DRINV11845', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:18:52'),
(258, 4, 'DRINV87458', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:19:28'),
(259, 4, 'DRINV68713', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:21:01'),
(260, 4, 'DRINV41995', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:23:54'),
(261, 4, 'DRINV79124', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:25:08'),
(262, 4, 'DRINV8596', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:26:33'),
(263, 4, 'DRINV10524', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:29:14'),
(264, 4, 'DRINV23576', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:29:44'),
(265, 4, 'DRINV53235', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:30:06'),
(266, 4, 'DRINV40130', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:32:33'),
(267, 4, 'DRINV92319', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:33:11'),
(268, 4, 'DRINV3157', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DR-45676', 820000, 820000, '2022-02-09 00:55:30', 0, 'paid', 'product Purchased', '2022-02-09 01:34:59'),
(269, 4, 'DRINV99478', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 1180000, 1180000, '2022-02-09 01:37:02', 0, 'paid', 'product Purchased', '2022-02-09 01:39:02'),
(270, 4, 'DRINV37257', 'Cost of Goods Sold', 'holy steps', 'HS-09909', 590000, 590000, '2022-02-09 01:39:13', 0, 'paid', 'product Purchased', '2022-02-09 01:40:48'),
(271, 4, 'DRINV97915', 'Cost of Goods Sold', 'Drew Inc Uganda', 'DRI-00032', 580000, 580000, '2022-02-10 04:00:12', 0, 'paid', 'product Purchased', '2022-02-10 04:01:31'),
(272, 4, 'DRINV98667', 'Cost of Goods Sold', 'Kampala Phones ', 'DR-45676', 1250010, 1250010, '2022-02-10 04:02:08', 0, 'paid', 'product Purchased', '2022-02-10 04:03:38'),
(273, 5, 'DREXC9133', 'bodaboda', 'Kassim', 'N/A', 10000, 10000, '2022-02-09 21:00:00', 0, 'Fully Paid', 'paid and done well', '2022-02-10 15:08:20'),
(274, 4, 'DRINV20281', 'Cost of Goods Sold', 'holy steps', '897798', 20000, 20000, '2022-02-15 15:40:18', 0, 'paid', 'product Purchased', '2022-02-15 15:40:53'),
(275, 4, 'DRINV11275', 'Cost of Goods Sold', 'holy steps', '897798', 20000, 20000, '2022-02-15 15:41:52', 0, 'paid', 'product Purchased', '2022-02-15 15:42:31'),
(276, 4, 'DRINV58055', 'Cost of Goods Sold', 'Muza Investiments ', '897798', 20000, 20000, '2022-02-16 06:07:13', 0, 'paid', 'product Purchased', '2022-02-16 06:09:54'),
(277, 4, 'DRINV79870', 'Cost of Goods Sold', 'Muza Investiments ', '897798', 20000, 20000, '2022-02-16 06:07:13', 0, 'paid', 'product Purchased', '2022-02-16 06:11:55'),
(278, 4, 'DRINV22177', 'Cost of Goods Sold', 'Muza Investiments ', '897798', 20000, 20000, '2022-02-16 06:07:13', 0, 'paid', 'product Purchased', '2022-02-16 06:17:18'),
(279, 4, 'DRINV70219', 'Cost of Goods Sold', 'Kampala Phones ', '12345', 800000, 800000, '2022-02-17 13:22:55', 0, 'paid', 'product Purchased', '2022-02-17 13:27:37'),
(280, 4, 'DRINV22748', 'Cost of Goods Sold', 'Kampala Phones ', '56783', 7200000, 400000, '2023-03-11 07:00:00', 6800000, 'pending', 'product Purchased', '2023-08-07 12:31:37');

-- --------------------------------------------------------

--
-- Table structure for table `expcat`
--

CREATE TABLE `expcat` (
  `expcat_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `exp_type` varchar(50) NOT NULL,
  `note` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expcat`
--

INSERT INTO `expcat` (`expcat_id`, `code`, `name`, `exp_type`, `note`, `date_added`) VALUES
(4, 'DREXC65980', 'Cost of Goods Sold', 'Operational', ' main source of income in the company', '2021-12-22 06:11:52'),
(5, 'DREXC15922', 'Transport', 'Operational', ' Logistics of Goods ', '2021-12-22 06:18:23'),
(6, 'DREXC70689', 'Rent', 'Operational', 'space where we work from', '2021-12-22 06:19:09'),
(7, 'DREXC4525', 'Service and utillities', 'Operational', 'water, Umeme among other s ', '2021-12-22 06:20:14'),
(8, 'DREXC94496', 'Others', 'Operational', 'other Expenses', '2021-12-22 06:21:50'),
(9, 'DREXC51050', 'repairs to equipment', 'Operational', 'repairs to equipment', '2021-12-22 06:33:25'),
(10, 'DREXC2432', 'Office supplies', 'Operational', ' Office supplies', '2021-12-22 06:33:49'),
(11, 'DREXC66394', 'Research and development costs', 'Operational', ' Research and development costs', '2021-12-22 06:34:57'),
(12, 'DREXC31679', 'marketing ', 'Non Operational', 'marketing  and advertisement ', '2021-12-23 12:11:22'),
(13, 'DREXC91944', 'Drinks', 'Non Operational', ' for staff lussry', '2023-02-14 15:08:33');

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE `income` (
  `income_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `inc_type` varchar(50) NOT NULL,
  `amount` bigint(255) NOT NULL,
  `user` varchar(50) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `income`
--

INSERT INTO `income` (`income_id`, `code`, `name`, `inc_type`, `amount`, `user`, `date_added`) VALUES
(1, 'DR-16141', 'Merchandise Sales', '0', 23000, 'administrator', '2021-12-18 07:46:06'),
(2, 'DR-96978', 'Merchandise Sales', '0', 23000, 'administrator', '2021-12-18 07:56:48'),
(5, 'DRS-64958', 'Merchandise Sales', 'Sales', 2000, 'administrator', '2021-12-18 08:45:42'),
(6, 'DRINC83393', 'Phone Repair', 'Tech', 50000, 'administrator', '2021-12-18 09:11:10'),
(7, 'DRINC61243', 'Sumsung Phone Repair', 'Tech', 12000, 'administrator', '2021-12-18 09:24:18'),
(8, 'DRS-59299', 'Merchandise Sales', 'Sales', 10000, 'administrator', '2021-12-19 06:05:38'),
(9, 'DRS-7112', 'Merchandise Sales', 'Sales', 1200000, 'administrator', '2022-01-01 05:46:55'),
(10, 'DRS-66440', 'Merchandise Sales', 'Sales', 14000, 'administrator', '2022-02-10 04:07:01'),
(11, 'DRS-37265', 'Merchandise Sales', 'Sales', 150000, 'administrator', '2022-02-17 13:50:41'),
(12, 'DRS-31180', 'Merchandise Sales', 'Sales', 134000, 'administrator', '2022-03-18 04:26:24'),
(13, 'DRS-73664', 'Merchandise Sales', 'Sales', 240000, 'administrator', '2022-04-02 08:13:10'),
(14, 'DRS-53836', 'Merchandise Sales', 'Sales', 100000, 'administrator', '2023-06-29 06:37:25'),
(15, 'DRS-49684', 'Merchandise Sales', 'Sales', 220000, 'administrator', '2023-07-10 09:43:36'),
(16, 'DRS-85473', 'Merchandise Sales', 'Sales', 0, 'administrator', '2023-08-02 04:25:21'),
(17, 'DRS-85473', 'Merchandise Sales', 'Sales', 0, 'administrator', '2023-08-02 04:25:59'),
(18, 'DRS-21112', 'Merchandise Sales', 'Sales', 0, 'administrator', '2024-07-02 03:37:42'),
(19, 'DRS-21112', 'Merchandise Sales', 'Sales', 0, 'administrator', '2024-07-02 03:37:59'),
(20, 'DRS-21112', 'Merchandise Sales', 'Sales', 0, 'administrator', '2024-07-02 03:39:13'),
(21, 'DRS-21112', 'Merchandise Sales', 'Sales', 0, 'administrator', '2024-07-02 03:39:29'),
(22, 'DRS-21112', 'Merchandise Sales', 'Sales', 0, 'administrator', '2024-07-02 03:42:18'),
(23, 'DRS-21112', 'Merchandise Sales', 'Sales', 0, 'administrator', '2024-07-02 03:44:43');

-- --------------------------------------------------------

--
-- Table structure for table `inv_count`
--

CREATE TABLE `inv_count` (
  `inv_count_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `inv_no` varchar(50) NOT NULL,
  `pay_status` varchar(50) NOT NULL,
  `amount` bigint(255) NOT NULL,
  `amount_paid` bigint(255) NOT NULL,
  `bal` bigint(255) NOT NULL,
  `due_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cashier` varchar(50) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inv_count`
--

INSERT INTO `inv_count` (`inv_count_id`, `code`, `inv_no`, `pay_status`, `amount`, `amount_paid`, `bal`, `due_date`, `cashier`, `date_added`) VALUES
(41, 'DRINV2533', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:07:26'),
(42, 'DRINV26997', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:09:41'),
(43, 'DRINV73679', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:11:05'),
(44, 'DRINV39631', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:30:32'),
(45, 'DRINV44369', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:32:47'),
(46, 'DRINV29117', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:33:26'),
(47, 'DRINV42433', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:34:47'),
(48, 'DRINV33749', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:35:21'),
(49, 'DRINV13094', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:35:56'),
(50, 'DRINV59828', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:37:39'),
(51, 'DRINV65573', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:38:30'),
(52, 'DRINV17014', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:39:16'),
(53, 'DRINV34328', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:42:15'),
(54, 'DRINV72565', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:53:59'),
(55, 'DRINV63692', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:56:54'),
(56, 'DRINV40086', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 00:57:10'),
(57, 'DRINV63023', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 01:09:09'),
(58, 'DRINV63158', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 01:10:02'),
(59, 'DRINV47136', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 01:10:26'),
(60, 'DRINV56884', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 01:11:01'),
(61, 'DRINV92725', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 01:11:23'),
(62, 'DRINV35172', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 01:11:52'),
(63, 'DRINV87591', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 01:12:15'),
(64, 'DRINV121', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 01:12:40'),
(65, 'DRINV50774', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 01:16:01'),
(66, 'DRINV83822', 'DHI-3908', 'paid', 80000, 0, 80000, '2021-12-07 22:49:24', 'administrator', '2021-12-08 01:16:53'),
(67, 'DRINV57216', '87092', 'paid', 500000, 0, 500000, '2021-12-19 16:31:33', 'administrator', '2021-12-19 16:32:57'),
(68, 'DRINV48303', '3453', 'paid', 500000, 0, 0, '2021-12-19 16:34:59', 'administrator', '2021-12-19 16:35:53'),
(69, 'DRINV94112', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:41:33'),
(70, 'DRINV47881', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:41:48'),
(71, 'DRINV79041', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:30'),
(72, 'DRINV93032', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:36'),
(73, 'DRINV31391', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:38'),
(74, 'DRINV84115', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:38'),
(75, 'DRINV64589', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:38'),
(76, 'DRINV62893', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:39'),
(77, 'DRINV77906', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:39'),
(78, 'DRINV36756', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:40'),
(79, 'DRINV99484', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:41'),
(80, 'DRINV45294', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:41'),
(81, 'DRINV7933', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:41'),
(82, 'DRINV34677', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:42'),
(83, 'DRINV27800', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:44:42'),
(84, 'DRINV95806', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:45:22'),
(85, 'DRINV55890', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:47:02'),
(86, 'DRINV21040', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:47:34'),
(87, 'DRINV27974', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:47:37'),
(88, 'DRINV12731', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:47:37'),
(89, 'DRINV57899', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:47:37'),
(90, 'DRINV20376', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:47:38'),
(91, 'DRINV45192', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:47:38'),
(92, 'DRINV70163', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:47:38'),
(93, 'DRINV10501', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:34'),
(94, 'DRINV48470', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:39'),
(95, 'DRINV20238', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:40'),
(96, 'DRINV80', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:40'),
(97, 'DRINV30753', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:45'),
(98, 'DRINV57913', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:47'),
(99, 'DRINV46816', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:47'),
(100, 'DRINV36586', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:48'),
(101, 'DRINV69161', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:49'),
(102, 'DRINV63671', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:49'),
(103, 'DRINV65515', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:49'),
(104, 'DRINV30944', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:50'),
(105, 'DRINV61091', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:50'),
(106, 'DRINV78427', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:50'),
(107, 'DRINV14703', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:50'),
(108, 'DRINV82613', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:51'),
(109, 'DRINV58956', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:51'),
(110, 'DRINV13359', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:51'),
(111, 'DRINV54708', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:52'),
(112, 'DRINV44133', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:52'),
(113, 'DRINV81941', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:52'),
(114, 'DRINV46036', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:52'),
(115, 'DRINV1632', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:53'),
(116, 'DRINV22664', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:53'),
(117, 'DRINV90378', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:54'),
(118, 'DRINV4185', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:48:54'),
(119, 'DRINV68382', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:50:33'),
(120, 'DRINV31001', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:56:16'),
(121, 'DRINV21235', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:56:42'),
(122, 'DRINV38406', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:57:02'),
(123, 'DRINV24520', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:57:33'),
(124, 'DRINV73684', 't-456554', 'paid', 225000, 0, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 04:58:09'),
(125, 'DRINV89442', 't-456554', 'paid', 225000, 225000, 0, '2021-12-28 04:20:44', 'administrator', '2021-12-28 10:22:08'),
(126, 'DRINV15636', 'DR-45676', 'paid', 125000, 0, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:38:12'),
(127, 'DRINV38607', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:43:16'),
(128, 'DRINV88312', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:44:08'),
(129, 'DRINV88312', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:44:08'),
(130, 'DRINV74781', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:44:42'),
(131, 'DRINV74781', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:44:42'),
(132, 'DRINV7908', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:49:46'),
(133, 'DRINV85647', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:49:58'),
(134, 'DRINV24534', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:51:03'),
(135, 'DRINV14176', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:52:22'),
(136, 'DRINV67125', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:52:56'),
(137, 'DRINV46088', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:53:21'),
(138, 'DRINV53354', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:54:11'),
(139, 'DRINV22651', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:54:31'),
(140, 'DRINV73875', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:54:59'),
(141, 'DRINV76619', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:57:13'),
(142, 'DRINV27509', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 17:57:49'),
(143, 'DRINV95439', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:05:24'),
(144, 'DRINV47855', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:08:19'),
(145, 'DRINV19562', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:11:03'),
(146, 'DRINV87721', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:11:14'),
(147, 'DRINV71582', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:11:28'),
(148, 'DRINV87053', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:12:06'),
(149, 'DRINV79440', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:15:53'),
(150, 'DRINV69903', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:16:14'),
(151, 'DRINV24642', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:16:42'),
(152, 'DRINV46037', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:18:11'),
(153, 'DRINV1590', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:21:59'),
(154, 'DRINV89590', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:24:41'),
(155, 'DRINV38102', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:27:31'),
(156, 'DRINV86337', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:27:41'),
(157, 'DRINV49158', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:28:22'),
(158, 'DRINV97964', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:32:31'),
(159, 'DRINV56698', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:32:45'),
(160, 'DRINV94286', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:36:50'),
(161, 'DRINV62959', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:39:43'),
(162, 'DRINV29046', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:40:10'),
(163, 'DRINV6122', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:41:34'),
(164, 'DRINV75269', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:41:46'),
(165, 'DRINV74561', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:42:23'),
(166, 'DRINV25430', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:43:57'),
(167, 'DRINV42025', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:44:11'),
(168, 'DRINV34147', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:44:36'),
(169, 'DRINV11497', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:47:17'),
(170, 'DRINV7925', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:47:56'),
(171, 'DRINV2989', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:51:33'),
(172, 'DRINV66839', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:52:48'),
(173, 'DRINV69354', 'DR-45676', 'paid', 125000, 125000, 0, '2021-12-28 12:16:53', 'administrator', '2021-12-30 18:54:25'),
(174, 'DRINV28156', 'HS-09909', 'paid', 350000, 350000, 0, '2022-01-28 16:03:48', 'administrator', '2022-01-28 23:56:35'),
(175, 'DRINV1718', 'HS-09909', 'paid', 350000, 350000, 0, '2022-01-28 16:03:48', 'administrator', '2022-01-28 23:57:42'),
(176, 'DRINV59480', 'HS-09909', 'paid', 350000, 350000, 0, '2022-01-28 16:03:48', 'administrator', '2022-01-28 23:57:59'),
(177, 'DRINV24294', 'HS-09909', 'paid', 350000, 350000, 0, '2022-01-28 16:03:48', 'administrator', '2022-01-28 23:59:08'),
(178, 'DRINV27286', 'DR-45676', 'pending', 13070000, 6000000, 7070000, '2022-04-29 21:00:00', 'administrator', '2022-01-29 00:36:47'),
(179, 'DRINV87795', 'DRI-00032', 'paid', 2200000, 2200000, 0, '2022-01-29 00:52:29', 'administrator', '2022-01-29 00:59:25'),
(180, 'DRINV8749', 'HS-09909', 'pending', 2400000, 2000000, 400000, '2022-04-02 21:00:00', 'administrator', '2022-02-05 13:02:54'),
(181, 'DRINV79380', 'DRI-00032', 'paid', 2490000, 2490000, 0, '2022-02-05 13:31:39', 'administrator', '2022-02-05 13:35:12'),
(182, 'DRINV11293', 'DRI-00032', 'paid', 2490000, 2490000, 0, '2022-02-05 13:31:39', 'administrator', '2022-02-05 13:41:45'),
(183, 'DRINV16247', 'DRI-00032', 'paid', 2490000, 2490000, 0, '2022-02-05 13:31:39', 'administrator', '2022-02-05 13:42:49'),
(184, 'DRINV10195', 'DRI-00032', 'paid', 2490000, 2490000, 0, '2022-02-05 13:31:39', 'administrator', '2022-02-05 13:47:36'),
(185, 'DRINV25776', 'HS-09909', 'paid', 2200000, 2200000, 0, '2022-02-06 00:21:59', 'administrator', '2022-02-06 00:44:54'),
(186, 'DRINV28490', 'DRI-00032', 'paid', 1950000, 1950000, 0, '2022-02-06 01:19:17', 'administrator', '2022-02-06 01:21:19'),
(187, 'DRINV40021', 'DRI-00032', 'paid', 1950000, 1950000, 0, '2022-02-06 01:19:17', 'administrator', '2022-02-06 01:21:26'),
(188, 'DRINV22092', 'DRI-00032', 'paid', 1950000, 1950000, 0, '2022-02-06 01:19:17', 'administrator', '2022-02-06 01:21:34'),
(189, 'DRINV93242', 'DRI-00032', 'paid', 1650000, 1650000, 0, '2022-02-06 01:25:48', 'administrator', '2022-02-06 01:30:54'),
(190, 'DRINV91642', 'DRI-00032', 'paid', 1650000, 1650000, 0, '2022-02-06 01:25:48', 'administrator', '2022-02-06 01:31:21'),
(191, 'DRINV81100', 'DRI-00032', 'paid', 1650000, 1650000, 0, '2022-02-06 01:25:48', 'administrator', '2022-02-06 01:32:49'),
(192, 'DRINV21548', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 01:49:55'),
(193, 'DRINV79324', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 01:52:19'),
(194, 'DRINV99604', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 01:53:12'),
(195, 'DRINV52734', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 01:53:49'),
(196, 'DRINV60393', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 01:55:31'),
(197, 'DRINV88593', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 02:04:00'),
(198, 'DRINV94786', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 02:11:06'),
(199, 'DRINV97831', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:06:42'),
(200, 'DRINV29412', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:07:00'),
(201, 'DRINV38034', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:12:43'),
(202, 'DRINV24656', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:13:01'),
(203, 'DRINV8187', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:15:33'),
(204, 'DRINV67395', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:16:33'),
(205, 'DRINV56953', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:28:31'),
(206, 'DRINV94013', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:28:53'),
(207, 'DRINV99903', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:29:45'),
(208, 'DRINV6348', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:31:17'),
(209, 'DRINV23089', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:33:10'),
(210, 'DRINV41661', 'HS-09909', 'paid', 500000, 500000, 0, '2022-02-06 01:48:53', 'administrator', '2022-02-06 03:39:02'),
(211, 'DRINV13270', 'HS-09909', 'paid', 1726000, 1726000, 0, '2022-02-06 03:41:22', 'administrator', '2022-02-06 03:43:35'),
(212, 'DRINV39173', 'DR-45676', 'paid', 380000, 380000, 0, '2022-02-06 04:51:43', 'administrator', '2022-02-06 04:52:58'),
(213, 'DRINV58509', 't-456554', 'paid', 5000, 5000, 0, '2022-02-06 04:54:24', 'administrator', '2022-02-06 04:55:15'),
(214, 'DRINV75166', 'DR-45676', 'paid', 380000, 380000, 0, '2022-02-06 05:04:56', 'administrator', '2022-02-06 05:05:32'),
(215, 'DRINV19435', 'DR-45676', 'paid', 380000, 380000, 0, '2022-02-06 05:04:56', 'administrator', '2022-02-06 05:07:16'),
(216, 'DRINV940', 'DR-45676', 'paid', 380000, 380000, 0, '2022-02-06 05:04:56', 'administrator', '2022-02-06 05:08:00'),
(217, 'DRINV78507', 'DR-45676', 'paid', 380000, 380000, 0, '2022-02-06 05:04:56', 'administrator', '2022-02-06 05:08:18'),
(218, 'DRINV39441', 'DR-45676', 'paid', 380000, 380000, 0, '2022-02-06 05:04:56', 'administrator', '2022-02-06 05:09:00'),
(219, 'DRINV61164', 'DR-45676', 'paid', 380000, 380000, 0, '2022-02-06 05:04:56', 'administrator', '2022-02-06 05:09:25'),
(220, 'DRINV99213', 'DR-45676', 'paid', 404000, 404000, 0, '2022-02-06 05:04:56', 'administrator', '2022-02-06 05:12:41'),
(221, 'DRINV51585', 'DR-45676', 'paid', 100000, 100000, 0, '2022-02-06 05:13:08', 'administrator', '2022-02-06 05:13:35'),
(222, 'DRINV9194', 'HS-09909', 'paid', 120000, 120000, 0, '2022-02-06 05:16:23', 'administrator', '2022-02-06 05:17:39'),
(223, 'DRINV33606', 'DR-45676', 'paid', 1900000, 1900000, 0, '2022-02-06 05:18:07', 'administrator', '2022-02-06 05:18:39'),
(224, 'DRINV47949', 'DR-45676', 'paid', 60000, 60000, 0, '2022-02-06 05:19:16', 'administrator', '2022-02-06 05:19:44'),
(225, 'DRINV71221', 'DR-45679', 'paid', 250000, 250000, 0, '2022-02-06 05:23:02', 'administrator', '2022-02-06 05:23:37'),
(226, 'DRINV9802', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:24:45'),
(227, 'DRINV57183', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:34:31'),
(228, 'DRINV63149', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:35:52'),
(229, 'DRINV33661', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:38:22'),
(230, 'DRINV97498', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:40:08'),
(231, 'DRINV14744', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:42:38'),
(232, 'DRINV48466', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:42:54'),
(233, 'DRINV14177', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:43:59'),
(234, 'DRINV41442', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:44:57'),
(235, 'DRINV22995', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:45:36'),
(236, 'DRINV8688', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:46:37'),
(237, 'DRINV3523', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:52:21'),
(238, 'DRINV48354', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:54:20'),
(239, 'DRINV55806', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:55:58'),
(240, 'DRINV30348', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:56:06'),
(241, 'DRINV93454', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 06:59:30'),
(242, 'DRINV76163', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:01:17'),
(243, 'DRINV24403', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:01:34'),
(244, 'DRINV6972', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:01:53'),
(245, 'DRINV86010', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:03:10'),
(246, 'DRINV19546', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:03:17'),
(247, 'DRINV58230', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:04:14'),
(248, 'DRINV31843', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:05:05'),
(249, 'DRINV20101', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:05:19'),
(250, 'DRINV5957', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:05:39'),
(251, 'DRINV17095', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:06:52'),
(252, 'DRINV99387', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:07:40'),
(253, 'DRINV14482', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:08:10'),
(254, 'DRINV55477', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:09:21'),
(255, 'DRINV73156', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:09:44'),
(256, 'DRINV30431', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:12:25'),
(257, 'DRINV89508', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:12:39'),
(258, 'DRINV60382', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:12:52'),
(259, 'DRINV4416', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:13:07'),
(260, 'DRINV72185', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:21:45'),
(261, 'DRINV44091', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:21:48'),
(262, 'DRINV68541', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:21:52'),
(263, 'DRINV22458', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:21:53'),
(264, 'DRINV84238', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:22:03'),
(265, 'DRINV95190', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:22:19'),
(266, 'DRINV41559', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:22:50'),
(267, 'DRINV1919', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:23:18'),
(268, 'DRINV80402', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:24:05'),
(269, 'DRINV11725', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:25:20'),
(270, 'DRINV17061', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:25:44'),
(271, 'DRINV86654', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:26:12'),
(272, 'DRINV75518', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:26:52'),
(273, 'DRINV69882', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:27:41'),
(274, 'DRINV9114', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:28:16'),
(275, 'DRINV43672', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:28:27'),
(276, 'DRINV14370', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:30:55'),
(277, 'DRINV78802', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:33:35'),
(278, 'DRINV83338', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:34:54'),
(279, 'DRINV47809', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:45:12'),
(280, 'DRINV7290', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:46:00'),
(281, 'DRINV27019', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:46:32'),
(282, 'DRINV79871', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:46:51'),
(283, 'DRINV97628', 't-456554', 'paid', 150000, 150000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:48:24'),
(284, 'DRINV53270', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:50:59'),
(285, 'DRINV64740', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:52:08'),
(286, 'DRINV64083', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:55:14'),
(287, 'DRINV9599', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:56:11'),
(288, 'DRINV81937', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 07:56:49'),
(289, 'DRINV96217', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:06:39'),
(290, 'DRINV66849', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:06:46'),
(291, 'DRINV94822', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:08:07'),
(292, 'DRINV46523', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:08:22'),
(293, 'DRINV13061', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:08:53'),
(294, 'DRINV87490', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:09:46'),
(295, 'DRINV34645', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:10:01'),
(296, 'DRINV6402', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:10:50'),
(297, 'DRINV1212', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:11:09'),
(298, 'DRINV10953', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:12:17'),
(299, 'DRINV20552', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:13:08'),
(300, 'DRINV37858', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:14:16'),
(301, 'DRINV30466', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:15:40'),
(302, 'DRINV25270', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:16:25'),
(303, 'DRINV13350', 't-456554', 'paid', 930000, 930000, 0, '2022-02-06 06:22:47', 'administrator', '2022-02-06 08:17:19'),
(304, 'DRINV55405', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:35:44'),
(305, 'DRINV44799', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:36:11'),
(306, 'DRINV81835', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:36:43'),
(307, 'DRINV55720', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:37:12'),
(308, 'DRINV41202', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:37:21'),
(309, 'DRINV83766', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:39:05'),
(310, 'DRINV99151', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:41:50'),
(311, 'DRINV77784', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:42:40'),
(312, 'DRINV64766', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:43:02'),
(313, 'DRINV52693', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:43:24'),
(314, 'DRINV79408', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:44:02'),
(315, 'DRINV37410', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:44:56'),
(316, 'DRINV35515', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:49:17'),
(317, 'DRINV93895', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-07 19:56:38'),
(318, 'DRINV4388', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:31:37'),
(319, 'DRINV40851', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:32:37'),
(320, 'DRINV25658', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:33:40'),
(321, 'DRINV47719', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:34:25'),
(322, 'DRINV28120', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:34:49'),
(323, 'DRINV71419', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:35:08'),
(324, 'DRINV25511', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:39:30'),
(325, 'DRINV55309', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:40:04'),
(326, 'DRINV76690', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:42:19'),
(327, 'DRINV30598', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:42:47'),
(328, 'DRINV19845', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:44:42'),
(329, 'DRINV7538', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:46:09'),
(330, 'DRINV46845', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:46:18'),
(331, 'DRINV27978', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:46:47'),
(332, 'DRINV21782', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:47:09'),
(333, 'DRINV47605', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:56:43'),
(334, 'DRINV42319', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:57:35'),
(335, 'DRINV23173', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 03:57:45'),
(336, 'DRINV42891', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:00:07'),
(337, 'DRINV52499', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:00:44'),
(338, 'DRINV83202', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:01:29'),
(339, 'DRINV7401', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:01:53'),
(340, 'DRINV14652', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:02:40'),
(341, 'DRINV12974', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:04:34'),
(342, 'DRINV7322', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:06:31'),
(343, 'DRINV11596', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:09:17'),
(344, 'DRINV64020', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:09:55'),
(345, 'DRINV41490', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:10:17'),
(346, 'DRINV19829', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:10:50'),
(347, 'DRINV41360', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:11:24'),
(348, 'DRINV83974', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:12:48'),
(349, 'DRINV68143', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:14:51'),
(350, 'DRINV22894', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:15:17'),
(351, 'DRINV20824', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:18:06'),
(352, 'DRINV44287', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:18:31'),
(353, 'DRINV11313', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:19:56'),
(354, 'DRINV28704', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:20:36'),
(355, 'DRINV72177', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:22:08'),
(356, 'DRINV9916', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:24:28'),
(357, 'DRINV31626', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:24:59'),
(358, 'DRINV2084', 'DRI-00032', 'paid', 2100000, 2100000, 0, '2022-02-07 19:34:18', 'administrator', '2022-02-08 04:32:31'),
(359, 'DRINV62050', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 14:50:22'),
(360, 'DRINV65996', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 14:51:19'),
(361, 'DRINV85483', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 14:51:27'),
(362, 'DRINV32913', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 14:54:13'),
(363, 'DRINV50471', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 14:57:35'),
(364, 'DRINV57552', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 14:59:53'),
(365, 'DRINV73531', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:00:17'),
(366, 'DRINV94069', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:07:39'),
(367, 'DRINV99904', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:07:55'),
(368, 'DRINV74935', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:09:38'),
(369, 'DRINV41502', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:10:08'),
(370, 'DRINV9401', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:12:48'),
(371, 'DRINV86211', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:13:11'),
(372, 'DRINV84720', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:13:29'),
(373, 'DRINV99266', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:13:45'),
(374, 'DRINV98888', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:14:07'),
(375, 'DRINV75550', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:14:10'),
(376, 'DRINV41633', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:14:43'),
(377, 'DRINV86564', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:15:10'),
(378, 'DRINV62063', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:15:40'),
(379, 'DRINV22274', '7809', 'paid', 1130000, 1130000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:24:10'),
(380, 'DRINV11669', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:25:21'),
(381, 'DRINV82643', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:26:32'),
(382, 'DRINV32035', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:28:52'),
(383, 'DRINV53348', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:29:45'),
(384, 'DRINV97983', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:30:39'),
(385, 'DRINV95751', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:31:10'),
(386, 'DRINV83402', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:31:42'),
(387, 'DRINV48270', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:32:17'),
(388, 'DRINV45314', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:36:10'),
(389, 'DRINV13164', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:37:20'),
(390, 'DRINV11450', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:38:27'),
(391, 'DRINV74919', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:39:39'),
(392, 'DRINV90915', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:40:03'),
(393, 'DRINV83993', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:41:12'),
(394, 'DRINV67996', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:41:48'),
(395, 'DRINV867', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:42:01'),
(396, 'DRINV13825', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:44:00'),
(397, 'DRINV79983', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:44:21'),
(398, 'DRINV39708', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:44:32'),
(399, 'DRINV82999', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:45:15'),
(400, 'DRINV5004', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:46:17'),
(401, 'DRINV69329', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:46:30'),
(402, 'DRINV94364', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:47:45'),
(403, 'DRINV28872', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:56:58'),
(404, 'DRINV31715', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:57:40'),
(405, 'DRINV54410', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:58:09'),
(406, 'DRINV56409', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:58:45'),
(407, 'DRINV26817', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 15:59:06'),
(408, 'DRINV60667', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:00:03'),
(409, 'DRINV3271', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:00:42'),
(410, 'DRINV26243', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:01:13'),
(411, 'DRINV21729', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:03:51'),
(412, 'DRINV98058', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:04:41'),
(413, 'DRINV99444', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:05:45'),
(414, 'DRINV24495', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:06:20'),
(415, 'DRINV38152', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:06:34'),
(416, 'DRINV76353', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:06:54'),
(417, 'DRINV13121', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:10:41'),
(418, 'DRINV51201', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:11:13'),
(419, 'DRINV38931', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:11:25'),
(420, 'DRINV50651', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:11:50'),
(421, 'DRINV87551', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:12:05'),
(422, 'DRINV53889', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:12:41'),
(423, 'DRINV36581', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:14:29'),
(424, 'DRINV86557', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:17:17'),
(425, 'DRINV71470', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:17:56'),
(426, 'DRINV56231', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:18:33'),
(427, 'DRINV65976', '7809', 'paid', 1930000, 1930000, 0, '2022-02-08 14:42:00', 'administrator', '2022-02-08 16:19:06'),
(428, 'DRINV59575', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 00:56:49'),
(429, 'DRINV66829', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 00:59:58'),
(430, 'DRINV83102', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:01:53'),
(431, 'DRINV20164', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:10:38'),
(432, 'DRINV2917', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:12:35'),
(433, 'DRINV18519', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:12:55'),
(434, 'DRINV50778', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:13:11'),
(435, 'DRINV26347', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:18:07'),
(436, 'DRINV11845', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:18:52'),
(437, 'DRINV87458', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:19:28'),
(438, 'DRINV68713', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:21:01'),
(439, 'DRINV41995', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:23:54'),
(440, 'DRINV79124', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:25:08'),
(441, 'DRINV8596', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:26:33'),
(442, 'DRINV10524', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:29:14'),
(443, 'DRINV23576', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:29:44'),
(444, 'DRINV53235', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:30:06'),
(445, 'DRINV40130', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:32:33'),
(446, 'DRINV92319', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:33:11'),
(447, 'DRINV3157', 'DR-45676', 'paid', 820000, 820000, 0, '2022-02-09 00:55:30', 'administrator', '2022-02-09 01:34:59'),
(448, 'DRINV99478', 'DRI-00032', 'paid', 1180000, 1180000, 0, '2022-02-09 01:37:02', 'administrator', '2022-02-09 01:39:02'),
(449, 'DRINV37257', 'HS-09909', 'paid', 590000, 590000, 0, '2022-02-09 01:39:13', 'administrator', '2022-02-09 01:40:48'),
(450, 'DRINV97915', 'DRI-00032', 'paid', 580000, 580000, 0, '2022-02-10 04:00:12', 'administrator', '2022-02-10 04:01:31'),
(451, 'DRINV98667', 'DR-45676', 'paid', 1250010, 1250010, 0, '2022-02-10 04:02:08', 'administrator', '2022-02-10 04:03:38'),
(452, 'DRINV20281', '897798', 'paid', 20000, 20000, 0, '2022-02-15 15:40:18', 'administrator', '2022-02-15 15:40:53'),
(453, 'DRINV11275', '897798', 'paid', 20000, 20000, 0, '2022-02-15 15:41:52', 'administrator', '2022-02-15 15:42:31'),
(454, 'DRINV58055', '897798', 'paid', 20000, 20000, 0, '2022-02-16 06:07:13', 'administrator', '2022-02-16 06:09:54'),
(455, 'DRINV79870', '897798', 'paid', 20000, 20000, 0, '2022-02-16 06:07:13', 'administrator', '2022-02-16 06:11:55');
INSERT INTO `inv_count` (`inv_count_id`, `code`, `inv_no`, `pay_status`, `amount`, `amount_paid`, `bal`, `due_date`, `cashier`, `date_added`) VALUES
(456, 'DRINV22177', '897798', 'paid', 20000, 20000, 0, '2022-02-16 06:07:13', 'administrator', '2022-02-16 06:17:18'),
(457, 'DRINV70219', '12345', 'paid', 800000, 800000, 0, '2022-02-17 13:22:55', 'administrator', '2022-02-17 13:27:37'),
(458, 'DRINV22748', '56783', 'pending', 7200000, 400000, 6800000, '2023-03-11 07:00:00', 'administrator', '2023-08-07 12:31:37');

-- --------------------------------------------------------

--
-- Table structure for table `mm_trans`
--

CREATE TABLE `mm_trans` (
  `trans_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `ac_no` varchar(50) NOT NULL,
  `c_name` varchar(50) NOT NULL,
  `rec_no` varchar(50) NOT NULL,
  `send_no` varchar(11) NOT NULL,
  `amount` bigint(11) NOT NULL,
  `trans_type` varchar(255) NOT NULL,
  `mmtrans_id` varchar(50) NOT NULL,
  `user_id` varchar(11) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mm_trans`
--

INSERT INTO `mm_trans` (`trans_id`, `code`, `ac_no`, `c_name`, `rec_no`, `send_no`, `amount`, `trans_type`, `mmtrans_id`, `user_id`, `date_added`) VALUES
(38, 'DRMMT-5193', '', 'Kizito', '0702789089', '0702050663', 50000, 'Withdraw', '4453267843', '', '2022-01-02 13:50:04'),
(39, 'DRMMT-6464', '3457477', 'Kizito', '0702789089', '0702050663', 50000, 'Deposit', '4453267843', '', '2022-01-02 14:27:08');

-- --------------------------------------------------------

--
-- Table structure for table `prodrec`
--

CREATE TABLE `prodrec` (
  `prodrec_id` int(11) NOT NULL,
  `bscode` varchar(50) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `prod_code` varchar(50) NOT NULL,
  `prod_sup` int(11) NOT NULL,
  `prod_cat` int(11) NOT NULL,
  `sup_inv_no` varchar(50) NOT NULL,
  `paym` varchar(50) NOT NULL,
  `qty` int(50) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `prods`
--

CREATE TABLE `prods` (
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `bscode` varchar(50) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `prod_code` varchar(50) NOT NULL,
  `qty` int(50) NOT NULL,
  `sub_cat_id` int(11) NOT NULL,
  `u_cost` bigint(255) NOT NULL,
  `u_price` bigint(50) NOT NULL,
  `u_profit` bigint(255) NOT NULL,
  `tcost` bigint(255) NOT NULL,
  `tprice` bigint(255) NOT NULL,
  `tprofit` bigint(255) NOT NULL,
  `date_added` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prods`
--

INSERT INTO `prods` (`prod_id`, `prod_name`, `bscode`, `sup_id`, `prod_code`, `qty`, `sub_cat_id`, `u_cost`, `u_price`, `u_profit`, `tcost`, `tprice`, `tprofit`, `date_added`) VALUES
(1, 'Rxd', 'DRBS-8320', 6, 'DRBS-7270', 60, 7, 2000, 15000, 13000, 300010, 520000, 390000, '2022-02-09 04:39:02'),
(2, 'Infinix hot 10', 'DRBS-8320', 6, 'DRBS-2257', 3, 1, 580000, 700000, 120000, 1380000, 420000, 300000, '2022-02-09 04:39:03'),
(3, 'Techno Spark', 'DRBS-8320', 1, 'DRBS-6922', 0, 5, 340000, 470000, 130000, 660000, 270000, 140000, '2022-02-09 04:39:03'),
(4, 'Infinix hot 10 cover', 'DRBS-6574', 7, 'DRBS-1969', 50, 1, 5000, 20000, 15000, 250000, 1000000, 750000, '2022-02-09 04:40:48'),
(5, 'Techno Spark 5', 'DRBS-9265', 3, 'DRBS-6589', 1, 5, 350000, 600000, 250000, 1050000, 1800000, 750000, '2022-02-10 07:03:38'),
(7, 'Rxd', 'DRBS-7050', 7, 'DRBS-6319', 8, 7, 2000, 10000, 8000, 20000, 100000, 80000, '2022-02-16 09:11:55'),
(8, 'Rxd', 'DRBS-7050', 7, 'DRBS-269', 10, 7, 2000, 10000, 8000, 20000, 100000, 80000, '2022-02-16 09:17:18'),
(9, 'technospark', 'DRBS-3287', 19, 'DRBS-4768', 2, 5, 400000, 550000, 150000, 800000, 1100000, 300000, '2022-02-17 16:27:37'),
(10, 'Infinix hot 30 series ', 'DRBS-9817', 19, 'DRBS-9471', 12, 1, 600000, 750000, 150000, 7200000, 9000000, 1800000, '2023-08-07 06:31:37');

-- --------------------------------------------------------

--
-- Table structure for table `prod_cat`
--

CREATE TABLE `prod_cat` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(50) NOT NULL,
  `cat_code` varchar(50) NOT NULL,
  `note` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prod_cat`
--

INSERT INTO `prod_cat` (`cat_id`, `cat_name`, `cat_code`, `note`, `date_added`) VALUES
(1, 'Smart Phones', 'DRCAT3706', ' Ok', '2022-02-06 01:16:26'),
(2, 'Accesories', 'DRCAT207', ' ok', '2022-02-06 01:16:35'),
(3, 'Basic Phone', 'DRCAT9157', ' Ok', '2022-02-06 01:16:47');

-- --------------------------------------------------------

--
-- Table structure for table `prod_sub_cat`
--

CREATE TABLE `prod_sub_cat` (
  `sub_cat_id` int(11) NOT NULL,
  `s_cat_code` varchar(50) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `s_cat_name` varchar(50) NOT NULL,
  `s_note` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prod_sub_cat`
--

INSERT INTO `prod_sub_cat` (`sub_cat_id`, `s_cat_code`, `cat_id`, `s_cat_name`, `s_note`, `date_added`) VALUES
(1, 'DRSCAT9882', 1, 'Infinix', ' ok', '2022-02-06 01:17:03'),
(5, 'DRSCAT9749', 1, 'Techo', ' kol\r\n', '2022-02-06 01:18:31'),
(6, 'DRSCAT8862', 1, 'Sumsung', ' ok', '2022-02-06 01:18:42'),
(7, 'DRSCAT2916', 2, 'Ear phone', ' kool', '2022-02-06 01:18:55'),
(8, 'DRSCAT9535', 1, 'Cover', ' ook', '2022-02-06 01:19:06');

-- --------------------------------------------------------

--
-- Table structure for table `prod_supply`
--

CREATE TABLE `prod_supply` (
  `prod_sup_id` int(11) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `bscode` varchar(50) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `sub_cat_id` int(11) NOT NULL,
  `qty` int(5) NOT NULL DEFAULT '1',
  `u_cost` int(255) NOT NULL,
  `u_price` int(255) NOT NULL,
  `u_profit` bigint(255) NOT NULL,
  `price` int(255) NOT NULL,
  `cost` int(255) NOT NULL,
  `profit` bigint(255) NOT NULL,
  `note` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prod_supply`
--

INSERT INTO `prod_supply` (`prod_sup_id`, `sup_id`, `bscode`, `prod_name`, `sub_cat_id`, `qty`, `u_cost`, `u_price`, `u_profit`, `price`, `cost`, `profit`, `note`, `date_added`) VALUES
(1, 6, 'DRBS-8320', 'Rxd', 7, 30, 2000, 15000, 13000, 450000, 60000, 390000, 'ok', '2022-02-09 01:37:53'),
(2, 6, 'DRBS-8320', 'Infinix hot 10', 1, 2, 400000, 550000, 150000, 1100000, 800000, 300000, 'ok', '2022-02-09 01:38:31'),
(3, 6, 'DRBS-8320', 'Techno Spark', 5, 1, 320000, 460000, 140000, 460000, 320000, 140000, 'ok', '2022-02-09 01:38:56'),
(4, 5, 'DRBS-6574', 'Techno Spark', 5, 1, 340000, 470000, 130000, 470000, 340000, 130000, 'ok', '2022-02-09 01:40:00'),
(5, 5, 'DRBS-6574', 'Infinix hot 10 cover', 1, 50, 5000, 20000, 15000, 1000000, 250000, 750000, 'ok', '2022-02-09 01:40:39'),
(6, 6, 'DRBS-3391', 'Infinix hot 10', 1, 1, 580000, 700000, 120000, 700000, 580000, 120000, 'ok', '2022-02-10 04:00:55'),
(7, 18, 'DRBS-9265', 'Techno Spark 5', 5, 3, 350000, 600000, 250000, 1800000, 1050000, 750000, 'ok', '2022-02-10 04:02:32'),
(8, 18, 'DRBS-9265', 'Rxd', 7, 10, 20001, 15000, -5001, 150000, 200010, -50010, 'ok', '2022-02-10 04:03:12'),
(9, 5, 'DRBS-1429', 'rxd', 7, 10, 2000, 15000, 13000, 150000, 20000, 130000, 'ok', '2022-02-15 15:40:43'),
(10, 5, 'DRBS-4634', 'Rxd', 7, 10, 2000, 15000, 13000, 150000, 20000, 130000, 'ok', '2022-02-15 15:42:25'),
(11, 7, 'DRBS-7050', 'Rxd', 7, 10, 2000, 10000, 8000, 100000, 20000, 80000, 'ok', '2022-02-16 06:09:43'),
(12, 19, 'DRBS-3287', 'technospark', 5, 2, 400000, 550000, 150000, 1100000, 800000, 300000, 'eoipouhy7fdsxs', '2022-02-17 13:23:59'),
(13, 19, 'DRBS-9817', 'Infinix hot 30 series ', 1, 12, 600000, 750000, 150000, 9000000, 7200000, 1800000, 'good for smart phone users', '2023-08-07 12:28:22');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL,
  `sinv_no` varchar(50) NOT NULL,
  `cust_name` varchar(100) NOT NULL,
  `cust_phone` varchar(50) NOT NULL,
  `cashier` varchar(50) NOT NULL,
  `amount_pay` bigint(255) NOT NULL,
  `amount_cost` bigint(255) NOT NULL,
  `profit` bigint(255) NOT NULL,
  `bal` bigint(255) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `sinv_no`, `cust_name`, `cust_phone`, `cashier`, `amount_pay`, `amount_cost`, `profit`, `bal`, `date_added`) VALUES
(1, 'DRS-66440', 'Nakamya Paula', '0789090890', 'administrator', 20000, 19000, 14000, 1000, '2022-02-10 04:07:01'),
(2, 'DRS-37265', 'job', '1234567890', 'administrator', 500000, 492000, 150000, 8000, '2022-02-17 13:50:40'),
(3, 'DRS-31180', 'Nakityo Paula', '0789768987', 'administrator', 480000, 478000, 134000, 2000, '2022-03-18 04:26:24'),
(4, 'DRS-66440', 'Nakamya Paula', '0789090890', 'Kityo Ivan', 20000, 19000, 14000, 1000, '2022-02-10 04:07:01'),
(5, 'DRS-66440', 'Nakamya Paula', '0789090890', 'administrator', 20000, 19000, 14000, 1000, '2022-02-10 04:07:01'),
(6, 'DRS-66440', 'Nakamya Paula', '0789090890', 'Kityo Ivan', 20000, 200000, 14000, 1000, '2022-02-10 04:07:01'),
(7, 'DRS-73664', 'Lwanga jacob', '079856743', 'administrator', 600000, 594000, 240000, 6000, '2022-04-02 08:13:10'),
(8, 'DRS-53836', 'kizito andrew', '0789022029', 'administrator', 450000, 440000, 100000, 10000, '2023-06-29 06:37:24'),
(9, 'DRS-49684', 'Lwanga  Ivan', '0756095903', 'administrator', 600000, 570000, 220000, 30000, '2023-07-10 09:43:36'),
(10, 'DRS-85473', 'Kizito', '0779114800', 'administrator', 1950000, 1193000, 0, 757000, '2023-08-02 04:25:21'),
(11, 'DRS-85473', 'Kizito', '0779114800', 'administrator', 1950000, 1193000, 0, 757000, '2023-08-02 04:25:59'),
(12, 'DRS-21112', 'kats', '0779114600', 'administrator', 1200000, 1112000, 0, 88000, '2024-07-02 03:37:42'),
(13, 'DRS-21112', 'kats', '0779114600', 'administrator', 1200000, 1112000, 0, 88000, '2024-07-02 03:37:59'),
(14, 'DRS-21112', 'kats', '0779114600', 'administrator', 1200000, 1112000, 0, 88000, '2024-07-02 03:39:13'),
(15, 'DRS-21112', 'kats', '0779114600', 'administrator', 1200000, 1112000, 0, 88000, '2024-07-02 03:39:29'),
(16, 'DRS-21112', 'kats', '0779114600', 'administrator', 1200000, 1112000, 0, 88000, '2024-07-02 03:42:18'),
(17, 'DRS-21112', 'kats', '0779114600', 'administrator', 1200000, 1112000, 0, 88000, '2024-07-02 03:44:43');

-- --------------------------------------------------------

--
-- Table structure for table `sales_order`
--

CREATE TABLE `sales_order` (
  `sales_order_id` int(11) NOT NULL,
  `sinv_no` varchar(100) NOT NULL,
  `prod_id` varchar(100) NOT NULL,
  `prod_code` varchar(150) NOT NULL,
  `prod_name` varchar(200) NOT NULL,
  `a_price` varchar(100) NOT NULL,
  `a_profit` int(11) NOT NULL,
  `sqty` int(50) NOT NULL,
  `t_cost` bigint(50) NOT NULL,
  `c_profit` mediumint(100) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_order`
--

INSERT INTO `sales_order` (`sales_order_id`, `sinv_no`, `prod_id`, `prod_code`, `prod_name`, `a_price`, `a_profit`, `sqty`, `t_cost`, `c_profit`, `date_added`) VALUES
(1, 'DRS-66440', '4', 'DRBS-1969', 'Infinix hot 10 cover', '19000', 14000, 1, 19000, 14000, '2022-02-10 04:05:02'),
(2, 'DRS-37265', '3', 'DRBS-6922', 'Techno Spark', '480000', 140000, 1, 480000, 140000, '2022-02-17 13:47:44'),
(3, 'DRS-37265', '1', 'DRBS-7270', 'Rxd', '12000', 10000, 1, 12000, 10000, '2022-02-17 13:48:23'),
(4, 'DRS-31180', '3', 'DRBS-6922', 'Techno Spark', '450000', 110000, 1, 450000, 110000, '2022-03-18 04:25:15'),
(5, 'DRS-31180', '1', 'DRBS-7270', 'Rxd', '14000', 12000, 2, 28000, 24000, '2022-03-18 04:25:42'),
(6, 'DRS-73664', '5', 'DRBS-6589', 'Techno Spark 5', '570000', 220000, 1, 570000, 220000, '2022-04-02 08:11:46'),
(7, 'DRS-73664', '1', 'DRBS-7270', 'Rxd', '12000', 10000, 2, 24000, 20000, '2022-04-02 08:12:27'),
(8, 'DRS-53836', '3', 'DRBS-6922', 'Techno Spark', '440000', 100000, 1, 440000, 100000, '2023-06-29 06:24:25'),
(9, 'DRS-16957', '4', 'DRBS-1969', 'Infinix hot 10 cover', '18000', 13000, 4, 72000, 52000, '2023-06-29 07:35:23'),
(10, 'DRS-38008', '1', 'DRBS-7270', 'Rxd', '10000', 8000, 4, 40000, 32000, '2023-06-30 00:47:44'),
(11, 'DRS-49684', '5', 'DRBS-6589', 'Techno Spark 5', '570000', 220000, 1, 570000, 220000, '2023-07-10 09:42:42'),
(12, 'DRS-85473', '3', 'DRBS-6922', 'Techno Spark', '460000', 120000, 1, 460000, 120000, '2023-08-02 04:01:54'),
(14, 'DRS-76469', '4', 'DRBS-1969', 'Infinix hot 10 cover', '17000', 12000, 1, 17000, 12000, '2023-08-02 04:07:20'),
(15, 'DRS-85473', '2', 'DRBS-2257', 'Infinix hot 10', '670000', 90000, 1, 670000, 90000, '2023-08-02 04:08:53'),
(16, 'DRS-85473', '1', 'DRBS-7270', 'Rxd', '10000', 8000, 1, 10000, 8000, '2023-08-02 04:09:24'),
(17, 'DRS-85473', '7', 'DRBS-6319', 'Rxd', '9000', 7000, 2, 18000, 14000, '2023-08-02 04:13:32'),
(18, 'DRS-85473', '7', 'DRBS-6319', 'Rxd', '7000', 5000, 1, 7000, 5000, '2023-08-02 04:14:20'),
(19, 'DRS-85473', '7', 'DRBS-6319', 'Rxd', '7000', 5000, 1, 7000, 5000, '2023-08-02 04:17:01'),
(20, 'DRS-85473', '7', 'DRBS-6319', 'Rxd', '7000', 5000, 1, 7000, 5000, '2023-08-02 04:19:00'),
(21, 'DRS-85473', '7', 'DRBS-6319', 'Rxd', '7000', 5000, 1, 7000, 5000, '2023-08-02 04:19:40'),
(22, 'DRS-85473', '7', 'DRBS-6319', 'Rxd', '7000', 5000, 1, 7000, 5000, '2023-08-02 04:19:55'),
(23, 'DRS-34913', '3', 'DRBS-6922', 'Techno Spark', '450000', 110000, 2, 900000, 220000, '2023-08-07 12:24:26'),
(24, 'DRS-21112', '5', 'DRBS-6589', 'Techno Spark 5', '550000', 200000, 2, 1100000, 400000, '2024-07-02 03:07:18'),
(25, 'DRS-21112', '1', 'DRBS-7270', 'Rxd', '12000', 10000, 1, 12000, 10000, '2024-07-02 03:09:16'),
(26, '0', '5', 'DRBS-6589', 'Techno Spark 5', '590000', 240000, 1, 590000, 240000, '2024-08-06 03:59:38'),
(27, '0', '5', 'DRBS-6589', 'Techno Spark 5', '599000', 249000, 1, 599000, 249000, '2024-08-06 04:03:30'),
(32, 'DRS-84098', '1', 'DRBS-7270', 'Rxd', '10000', 0, 2, 20000, 0, '2024-08-06 04:23:36'),
(33, 'DRS-50552', '5', 'DRBS-6589', 'Techno Spark 5', '550000', 0, 1, 550000, 0, '2024-08-06 04:34:46');

-- --------------------------------------------------------

--
-- Table structure for table `sold_out`
--

CREATE TABLE `sold_out` (
  `soldout_id` int(11) NOT NULL,
  `sales_id` int(11) NOT NULL,
  `sales_order_id` varchar(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `inv_no` varchar(50) NOT NULL,
  `qty` int(20) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `supliers`
--

CREATE TABLE `supliers` (
  `sup_id` int(11) NOT NULL,
  `sup_code` varchar(50) NOT NULL,
  `sup_name` varchar(100) NOT NULL,
  `sup_address` varchar(100) NOT NULL,
  `sup_contact` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `balance_due` int(11) DEFAULT '0',
  `note` varchar(500) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supliers`
--

INSERT INTO `supliers` (`sup_id`, `sup_code`, `sup_name`, `sup_address`, `sup_contact`, `contact_person`, `balance_due`, `note`, `date_added`) VALUES
(5, '0', 'holy steps', 'Plot 905, Kabakanjagala Road, Bulange Mengo', '+256789428207 /+256756191100', 'jimmy', 0, '\nEmail: info@cbspewosacoop.com  website: https://cbspewosacoop.com', '2021-12-10 15:16:49'),
(6, '0', 'Drew Inc Uganda', 'Plot 905, Kabakanjagala Road, Bulange Mengo', '+256789428207 /+256756191100', 'Kizito Andrew', 0, 'They suplu genuine products from abroad', '2021-12-10 15:16:49'),
(7, '0', 'Muza Investiments ', 'Kikubo', '079882678', 'muzanganda', 0, 'ok', '2021-12-10 15:16:49'),
(18, 'DRSUP87933', 'Kampala Phones ', '', '0789373673', 'Mutyaba Twalib', 0, 'good for today ', '2021-12-11 07:19:34'),
(19, 'DRSUP92956', 'Kampala Phones ', '', '0789373673', 'Mutyaba Twalib', 0, 'good for today ', '2021-12-11 07:19:53'),
(20, 'DRSUP20424', 'Katumwa', '', '078990208', 'Kizito Katumwa', 0, 'GOod jasse ', '2021-12-12 02:42:44'),
(21, 'DRSUP59045', 'ASTRA PHARMA', '', '095598O6', 'LIM', 0, ' ', '2024-08-07 05:03:01');

-- --------------------------------------------------------

--
-- Table structure for table `sup_banch`
--

CREATE TABLE `sup_banch` (
  `sup_banch_id` int(11) NOT NULL,
  `bscode` varchar(50) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `sup_inv_no` varchar(50) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sup_banch`
--

INSERT INTO `sup_banch` (`sup_banch_id`, `bscode`, `sup_id`, `sup_inv_no`, `date_added`) VALUES
(1, 'DRBS-4633', 6, 'DRI-00032', '2022-02-09 01:36:18'),
(2, 'DRBS-8320', 6, 'DRI-00032', '2022-02-09 01:37:02'),
(3, 'DRBS-6574', 5, 'HS-09909', '2022-02-09 01:39:13'),
(4, 'DRBS-3391', 6, 'DRI-00032', '2022-02-10 04:00:12'),
(5, 'DRBS-9265', 18, 'DR-45676', '2022-02-10 04:02:08'),
(6, 'DRBS-1429', 5, '897798', '2022-02-15 15:40:18'),
(7, 'DRBS-4634', 5, '897798', '2022-02-15 15:41:52'),
(8, 'DRBS-7050', 7, '897798', '2022-02-16 06:07:13'),
(9, 'DRBS-3287', 19, '12345', '2022-02-17 13:22:55'),
(10, 'DRBS-9817', 19, '56783', '2023-08-07 12:26:52');

-- --------------------------------------------------------

--
-- Table structure for table `tech`
--

CREATE TABLE `tech` (
  `tec_id` int(11) NOT NULL,
  `c_name` varchar(50) NOT NULL,
  `device` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `SN` varchar(50) NOT NULL,
  `Problem` text NOT NULL,
  `issue_type` varchar(50) NOT NULL,
  `amount` bigint(255) NOT NULL,
  `amount_paid` bigint(255) NOT NULL,
  `pickup_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `balance` bigint(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `u_code` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `position` varchar(100) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `u_code`, `username`, `password`, `name`, `address`, `email`, `phone`, `position`, `date_added`) VALUES
(9, 'DRU8492', 'admin', 'admin', 'administrator', 'Katwe', 'admin@gmail.com', '078987656', 'Admin', '2021-07-13 04:52:26'),
(10, 'DRU8494', 'kityo', 'ivan', 'kityo Ivan', 'Ndejje', 'kityo@drewpos.com', '078987656', 'Cashier', '2021-07-13 05:31:12'),
(16, 'DRU8497', 'medy', 'medy', 'an', 'an', 'ab', '078987656', 'Inventory Manager', '2021-09-17 19:51:33'),
(17, 'DRU8491', 'Kizito', 'admin', 'Kizito andrew', 'katwe', 'ak@gmail.com', '0779114800', 'Admin', '2022-03-18 12:24:32'),
(18, 'DRU8499', 'Kizito', 'admin', 'Kizito andrew', 'katwe', 'ak@gmail.com', '0779114800', 'Admin', '2022-03-18 12:24:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comp_acc`
--
ALTER TABLE `comp_acc`
  ADD PRIMARY KEY (`acc_id`),
  ADD UNIQUE KEY `acc_number` (`acc_number`);

--
-- Indexes for table `comp_bra`
--
ALTER TABLE `comp_bra`
  ADD PRIMARY KEY (`comp_bra_id`);

--
-- Indexes for table `comp_det`
--
ALTER TABLE `comp_det`
  ADD PRIMARY KEY (`comp_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cust_id`),
  ADD UNIQUE KEY `cust_code` (`cust_code`);

--
-- Indexes for table `exp`
--
ALTER TABLE `exp`
  ADD PRIMARY KEY (`exp_id`);

--
-- Indexes for table `expcat`
--
ALTER TABLE `expcat`
  ADD PRIMARY KEY (`expcat_id`);

--
-- Indexes for table `income`
--
ALTER TABLE `income`
  ADD PRIMARY KEY (`income_id`);

--
-- Indexes for table `inv_count`
--
ALTER TABLE `inv_count`
  ADD PRIMARY KEY (`inv_count_id`);

--
-- Indexes for table `mm_trans`
--
ALTER TABLE `mm_trans`
  ADD PRIMARY KEY (`trans_id`);

--
-- Indexes for table `prodrec`
--
ALTER TABLE `prodrec`
  ADD PRIMARY KEY (`prodrec_id`);

--
-- Indexes for table `prods`
--
ALTER TABLE `prods`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `prod_cat`
--
ALTER TABLE `prod_cat`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `prod_sub_cat`
--
ALTER TABLE `prod_sub_cat`
  ADD PRIMARY KEY (`sub_cat_id`),
  ADD UNIQUE KEY `s_cat_code` (`s_cat_code`);

--
-- Indexes for table `prod_supply`
--
ALTER TABLE `prod_supply`
  ADD PRIMARY KEY (`prod_sup_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`);

--
-- Indexes for table `sales_order`
--
ALTER TABLE `sales_order`
  ADD PRIMARY KEY (`sales_order_id`);

--
-- Indexes for table `sold_out`
--
ALTER TABLE `sold_out`
  ADD PRIMARY KEY (`soldout_id`);

--
-- Indexes for table `supliers`
--
ALTER TABLE `supliers`
  ADD PRIMARY KEY (`sup_id`);

--
-- Indexes for table `sup_banch`
--
ALTER TABLE `sup_banch`
  ADD PRIMARY KEY (`sup_banch_id`),
  ADD UNIQUE KEY `sup_banch_code` (`bscode`);

--
-- Indexes for table `tech`
--
ALTER TABLE `tech`
  ADD PRIMARY KEY (`tec_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comp_acc`
--
ALTER TABLE `comp_acc`
  MODIFY `acc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comp_bra`
--
ALTER TABLE `comp_bra`
  MODIFY `comp_bra_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `comp_det`
--
ALTER TABLE `comp_det`
  MODIFY `comp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exp`
--
ALTER TABLE `exp`
  MODIFY `exp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=281;

--
-- AUTO_INCREMENT for table `expcat`
--
ALTER TABLE `expcat`
  MODIFY `expcat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `income`
--
ALTER TABLE `income`
  MODIFY `income_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `inv_count`
--
ALTER TABLE `inv_count`
  MODIFY `inv_count_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=459;

--
-- AUTO_INCREMENT for table `mm_trans`
--
ALTER TABLE `mm_trans`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `prodrec`
--
ALTER TABLE `prodrec`
  MODIFY `prodrec_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prods`
--
ALTER TABLE `prods`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `prod_cat`
--
ALTER TABLE `prod_cat`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `prod_sub_cat`
--
ALTER TABLE `prod_sub_cat`
  MODIFY `sub_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `prod_supply`
--
ALTER TABLE `prod_supply`
  MODIFY `prod_sup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `sales_order`
--
ALTER TABLE `sales_order`
  MODIFY `sales_order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `sold_out`
--
ALTER TABLE `sold_out`
  MODIFY `soldout_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supliers`
--
ALTER TABLE `supliers`
  MODIFY `sup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `sup_banch`
--
ALTER TABLE `sup_banch`
  MODIFY `sup_banch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tech`
--
ALTER TABLE `tech`
  MODIFY `tec_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
