<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session
session_save_path('/tmp');
session_start();

// Include database connection
include('includes/connect.php');

// Array to store validation errors
$errmsg_arr = array();

// Validation error flag
$errflag = false;

// Function to sanitize values received from the form to prevent SQL injection
function clean($str, $conn) {
    return mysqli_real_escape_string($conn, trim($str));
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize the POST values
    $login = clean($_POST['username'], $conn);
    $password = clean($_POST['password'], $conn);

    // Input Validations
    if (empty($login)) {
        $errmsg_arr[] = 'Username missing';
        $errflag = true;
    }
    if (empty($password)) {
        $errmsg_arr[] = 'Password missing';
        $errflag = true;
    }

    // If there are input validations, redirect back to the login form
    if ($errflag) {
        $_SESSION['ERRMSG_ARR'] = $errmsg_arr;
        session_write_close();
        header("Location: index.php");
        exit();
    }

    // Create query
    $qry = "SELECT * FROM user WHERE username='$login'";
    $result = mysqli_query($conn, $qry);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $member = mysqli_fetch_assoc($result);

            // Verify password
            if ( $password==$member['password']) {
                // Password is correct
                session_regenerate_id();
                $_SESSION['mem_id'] = $member['id'];
                $_SESSION['mem_name'] = $member['name'];
                $_SESSION['mem_position'] = $member['position'];

                session_write_close();
                switch ($_SESSION['mem_position']) {
                    case 'Admin':
                        header("Location: main/home.php");
                        break;
                    case 'Inventory Manager':
                        header("Location: stock/home.php");
                        break;
                    case 'Cashier':
                        header("Location: cash/home.php");
                        break;
                    default:
                        $errmsg_arr[] = 'Invalid user role';
                        $_SESSION['ERRMSG_ARR'] = $errmsg_arr;
                        header("Location: index.php");
                        exit();
                }
                exit();
            } else {
                // Invalid password
                $errmsg_arr[] = 'Invalid username or password';
                $_SESSION['ERRMSG_ARR'] = $errmsg_arr;
                header("Location: index.php");
                exit();
            }
        } else {
            // Username not found
            $errmsg_arr[] = 'Invalid username or password';
            $_SESSION['ERRMSG_ARR'] = $errmsg_arr;
            header("Location: index.php");
            exit();
        }
    } else {
        die("Query failed: " . mysqli_error($conn));
    }
}

// Unset any session variables for a fresh login
unset($_SESSION['mem_id']);
unset($_SESSION['mem_name']);
unset($_SESSION['mem_position']);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DREWGMS | Admin-Log in</title>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<body class="hold-transition login-page">
<div class="login-box">
    <div class="card card-outline card-primary">
        <div class="card-header text-center">
            <img src="drewpos.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
            <a href="index2.html" class="h1"><b>DREW</b>POS</a>
        </div>
        <div class="card-body">
            <p class="login-box-msg">
                <?php
                if (isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) > 0) {
                    foreach ($_SESSION['ERRMSG_ARR'] as $msg) {
                        echo '<div style="color: red; text-align: center;">', htmlspecialchars($msg), '</div><br>'; 
                    }
                    unset($_SESSION['ERRMSG_ARR']);
                }
                ?>
            </p> 
            <form name="loginform" action="" method="post" autocomplete="off">
                <div class="input-group mb-3">
                    <input type="text" name="username" class="form-control" placeholder="Username" required>
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-envelope"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8"></div>
                    <div class="col-4">
                        <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
