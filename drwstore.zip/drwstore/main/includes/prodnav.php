
<ul class="nav nav-tabs">
            <li class="nav-item  
            <?php 
                if ($tag =="prods") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=prods"> Products</a>
            </li>
            <li class="nav-item 
            <?php 
                if ($tag =="cats") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link " href="home.php?tag=cats">Product Category </a>
            </li>
            <li class="nav-item 
            <?php 
                if ($tag =="sups") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link " href="home.php?tag=sups">Product Suppliers </a>
            </li>
        </ul>
        