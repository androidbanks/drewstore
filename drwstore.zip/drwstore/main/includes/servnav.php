
<ul class="nav nav-tabs">
            <li class="nav-item 
            <?php 
                if ($tag =="set") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link " href="home.php?tag=emp"><i class="fas fa-home"></i> </a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="accset") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=addemp"> Add Employee</a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="pendset") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=payroll"> Payroll </a>
            </li>
 

             
        </ul>
        