    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-12 col-sm-12 col-md-5">
            <h1 class="m-0">
               <?php
       if ($tag=="dash" or $tag=="") {
              echo 'Dashboard';
           }elseif ($tag=="sales") { 
               echo'#'. $_GET['sinv_no'];  
           }elseif ($tag=="salesres") { 
              echo'#'. $_GET['sinv_no'];  
           }elseif ($tag=="dsale") { 
               echo'#'.$_GET['sinv_no'];  
           }elseif ($tag=="csale") { 
               echo'#'. $_GET['sinv_no'];  
           }elseif ($tag=="bout") { 
               echo'#'. $_GET['sinv_no'];  
           }elseif ($tag=="rcpt") { 
              echo'#'. "Invoice No: #". $_GET['sinv_no']; 
           }



           elseif ($tag=="inc") { 
              echo "Incomes"; 
           }
           



           elseif ($tag=="exp") { 
              echo "Expenses";  
           }



       elseif ($tag=="prods") {
            echo "Products In Stock";
       }elseif ($tag=="addprods") {
            echo "Add products to stock";
       }elseif ($tag=="abprods") {
             echo "Add Products Supplied";
       }elseif ($tag=="psup") { 
            echo "Products Recived";
       }elseif ($tag=="apay") {
            echo "Make Payments";
       }elseif ($tag=="vbch") { 
            echo "View Recieved Banch";
       }elseif ($tag=="addprodsupplied") {  
           echo "Dashboard";
       }elseif ($tag=="addbanchprod") {  
            echo "Dashboard";
       }elseif ($tag=="ceckprodsup") {  
             echo "Dashboard";
       }elseif ($tag=="ats") {  
            echo "Dashboard";
       }elseif ($tag=="apts") {  
            echo "Dashboard";
       }elseif ($tag=="dpfb") {  
             echo "Dashboard";
       }
       

       elseif ($tag=="category") {
             echo "Products Category";
       }elseif ($tag=="Supplier") {
            echo "Suppliers";
       } elseif ($tag=="profile") {
              echo $usr."'s profile";
       } elseif ($tag=="users") {
             echo "Users";
       }elseif ($tag=="rpts") {
             echo "Reports";
           }elseif ($tag=="rptsslr") { 
             echo "Sales Reports";
           }elseif ($tag=="rptsstk") { 
             echo "Stock Reports";
           }elseif ($tag=="rptsbs") { 
             echo "Balance Sheet";
           }elseif ($tag=="rptspal") { 
             echo "Profits and Loss Report";
           }elseif ($tag=="supplier") { 
             echo "Dashboard";
           } 

       else{
        echo "page Not Found ";
       }
       ?>  

            </h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"> <?php
       if ($tag=="dash" or $tag=="") {
          echo "";
       }elseif ($tag=="sales") { 
               echo'#'. $_GET['sinv_no'];  
           }elseif ($tag=="salesres") { 
              echo'#'. $_GET['sinv_no'];  
           }elseif ($tag=="dsale") { 
               echo'#'.$_GET['sinv_no'];  
           }elseif ($tag=="csale") { 
               echo'#'. $_GET['sinv_no'];  
           }elseif ($tag=="bout") { 
               echo'#'. $_GET['sinv_no'];  
           }elseif ($tag=="rcpt") { 
              echo'#'. "Invoice No: #". $_GET['sinv_no']; 
           }


           elseif ($tag=="inc") { 
              echo "Incomes"; 
           }
           



           elseif ($tag=="exp") { 
              echo "Expenses";  
           }


       elseif ($tag=="prods") {
            echo "Products In Stock";
       }elseif ($tag=="addprods") {
            echo "Add Products";
       }elseif ($tag=="abprods") {
             echo "Products Supplied";
       }elseif ($tag=="psup") { 
            echo "Products Recived";
       }elseif ($tag=="apay") {
            echo "Make Payments";
       }elseif ($tag=="vbch") {  
            echo "View Recieved Banch";
       }elseif ($tag=="addprodsupplied") {  
           echo "Dashboard";
       }elseif ($tag=="addbanchprod") {  
            echo "Dashboard";
       }elseif ($tag=="ceckprodsup") {  
             echo "Dashboard";
       }elseif ($tag=="ats") {  
            echo "Dashboard";
       }elseif ($tag=="apts") {  
            echo "Dashboard";
       }elseif ($tag=="dpfb") {  
             echo "Dashboard";
       }
       

       elseif ($tag=="category") {
             echo "Products Category";
       }elseif ($tag=="Supplier") {
            echo "Suppliers";
       } elseif ($tag=="profile") {
              echo $usr."'s profile";
       } elseif ($tag=="users") {
             echo "Users";
       }elseif ($tag=="rpt") {
             echo "Reports";
           }elseif ($tag=="stkrpt") { 
             echo "Sales Reports";
           }elseif ($tag=="rptsstk") { 
             echo "Stock Reports";
           }elseif ($tag=="rptsbs") { 
             echo "Balance Sheet";
           }elseif ($tag=="rptspal") { 
             echo "Profits and Loss Report";
           }elseif ($tag=="supplier") { 
             echo "Dashboard";
           } 

       else{
        echo "page Not Found ";
       }
       ?>  </li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>