
<ul class="nav nav-tabs">
            <li class="nav-item 
            <?php 
                if ($tag =="rpt") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link " href="home.php?tag=rpt"><i class="fas fa-home"></i> </a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="fsrpt") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=fsrpt"> Sales report</a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="stkrpt") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=stkrpt"> Stock Reports</a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="incrpt") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=incrpt">Income Statement</a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="cfsrpt") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=cfsrpt"> Cash Flow statement</a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="bsrpt") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=blsheet"> Balance Sheet</a>
            </li>
             
        </ul>
        