 <ul class="nav flex-column nav-tabs">
            <li class="nav-item 
            <?php 
                if ($tag == "addmm") {
                  echo "active";
                } else {
                  echo "";
                }
            ?>">
                <a class="nav-link" href="home.php?tag=addmm"><i class="fas fa-home"></i> Home</a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag == "mm") {
                  echo "active";
                } else {
                  echo "";
                }
            ?>">
                <a class="nav-link" href="home.php?tag=mm">Mobile Money</a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag == "mmcat") {
                  echo "active";
                } else {
                  echo "";
                }
            ?>">
                <a class="nav-link" href="home.php?tag=mmcat">Mobile Money Reports</a>
            </li>
        </ul>