
<ul class="nav nav-tabs">
            <li class="nav-item 
            <?php 
                if ($tag =="srep") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link " href="home.php?tag=srepdash"><i class="fas fa-home"></i> </a>
            </li>
            <li class="nav-item 
            <?php 
                if ($tag =="srep") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link " href="home.php?tag=srep">Sales </a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="exp") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=exp"> Daily Sales </a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="expcat") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=expcat"> Staff Performance </a>
            </li>
             
        </ul>
        