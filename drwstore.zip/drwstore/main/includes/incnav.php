
<ul class="nav nav-tabs">
            <li class="nav-item  
            <?php 
                if ($tag =="inc") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=inc"> Incomes</a>
            </li>
            <li class="nav-item 
            <?php 
                if ($tag =="addinc") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link " href="home.php?tag=inccat">Income Category</a>
            </li>
             
        </ul>
        