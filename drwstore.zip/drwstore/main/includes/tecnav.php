
<ul class="nav nav-tabs">
            <li class="nav-item 
            <?php 
                if ($tag =="tec") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link " href="home.php?tag=tec"><i class="fas fa-home"></i> </a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="addtec") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=addtec"> Add Issue</a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="pendtec") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=pendtec"> Pending Issues </a>
            </li>
             
        </ul>
        