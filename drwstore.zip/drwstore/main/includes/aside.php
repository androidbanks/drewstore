
    <style>
        /* Custom Styles for Sidebar */
        .main-sidebar {
            background-color: #343a40; /* Dark background for sidebar */
            color: #ffffff;
            border-right: 1px solid #444;
        }

        .brand-link {
            display: flex;
            align-items: center;
            padding: 15px;
            background-color: #222;
            border-bottom: 1px solid #444;
            color: #ffffff;
            text-decoration: none;
        }

        .brand-link .brand-image {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .brand-link .brand-text {
            font-size: 1.25rem;
            font-weight: 600;
        }

        .sidebar {
            padding: 20px 15px;
        }

        .user-panel {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .user-panel .image {
            margin-right: 15px;
        }

        .user-panel .image img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid #ffffff;
        }

        .user-panel .info {
            flex: 1;
        }

        .user-panel .info a {
            color: #ffffff;
            font-weight: 500;
            text-transform: capitalize;
            font-size: 1rem;
            text-decoration: none;
        }

        .nav-sidebar .nav-link {
            color: #ffffff;
            padding: 10px 15px;
            border-radius: 5px;
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .nav-sidebar .nav-link:hover {
            background-color: #495057;
            color: #ffffff;
        }

        .nav-sidebar .nav-link.active {
            background-color: #007bff;
            color: #ffffff;
        }

        .nav-icon {
            font-size: 1.3rem;
            margin-right: 10px;
        }

        .nav-pills .nav-link {
            padding: 10px;
        }
    </style>
</head>
<body>
<aside class="main-sidebar  elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
        <img src="../drewpos.png" alt="DREWPOS Logo" class="brand-image img-circle elevation-3">
        <span class="brand-text">DREWPOS</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="../pp.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo htmlspecialchars($_SESSION['mem_name']); ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
   <nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Dashboard -->
        <li class="nav-item">
            <a href="home.php?tag=dash" class="nav-link">
                <i class="nav-icon fas fa-home"></i>
                <p>Dashboard</p>
            </a>
        </li>

        <!-- Sales -->
        <li class="nav-item">
            <a href="home.php?tag=sales&sinv_no=<?php echo 'DRS-' . rand(1, 99999); ?>" class="nav-link">
                <i class="nav-icon fas fa-cash-register"></i>
                <p>Sales</p>
            </a>
        </li>

        <!-- Products -->
        <li class="nav-item">
            <a href="home.php?tag=prods" class="nav-link">
                <i class="nav-icon fas fa-archive"></i>
                <p>Products</p>
            </a>
        </li>

        <!-- Other Services -->
        <li class="nav-item">
            <a href="home.php?tag=mm" class="nav-link">
                <i class="nav-icon fas fa-concierge-bell"></i>
                <p>Other Services</p>
            </a>
        </li>

        <!-- Reports -->
        <li class="nav-item">
            <a href="home.php?tag=rpt" class="nav-link">
                <i class="nav-icon fas fa-clipboard-list"></i>
                <p>Reports</p>
            </a>
        </li>

        <!-- Settings -->
        <li class="nav-item">
            <a href="home.php?tag=set" class="nav-link">
                <i class="nav-icon fas fa-tools"></i>
                <p>Settings</p>
            </a>
        </li>
    </ul>
</nav>

        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>

 
