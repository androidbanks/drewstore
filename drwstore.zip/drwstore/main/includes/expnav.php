
<ul class="nav nav-tabs">
            <li class="nav-item 
            <?php 
                if ($tag =="addexp") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link " href="home.php?tag=addexp"><i class="fas fa-home"></i> </a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="exp") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=exp"> Expenses</a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="expcat") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=expcat"> Expenses Categories</a>
            </li>
             
        </ul>
        