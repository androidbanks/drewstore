
<ul class="nav nav-tabs">
            <li class="nav-item 
            <?php 
                if ($tag =="set") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link " href="home.php?tag=set"><i class="fas fa-home"></i> </a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="accset") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=accset"> Accounts</a>
            </li>
            <li class="nav-item  
            <?php 
                if ($tag =="pendset") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=user"> Users </a>
            </li>

            <li class="nav-item  
            <?php 
                if ($tag =="pendset") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=pol"> Policies </a>
            </li>

            <li class="nav-item  
            <?php 
                if ($tag =="pendset") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link" href="home.php?tag=o_set"> other Services </a>
            </li>


            <li class="nav-item  
            <?php 
                if ($tag =="comp_set") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link"  href="home.php?tag=comp_det"> Company Details </a>
            </li>

             
            <li class="nav-item  
            <?php 
                if ($tag =="comp_set") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link"  href="home.php?tag=exp" > Expenses </a>
            </li>
             
            <li class="nav-item  
            <?php 
                if ($tag =="comp_set") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link"  href="http://drewincug.com"> Other Incomes </a>
            </li>
             
            <li class="nav-item  
            <?php 
                if ($tag =="comp_set") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link"  href="home.php?tag=emp" > Employees </a>
            </li>
             

            <li class="nav-item  
            <?php 
                if ($tag =="comp_set") {
                  echo "active";
                }else{
                    echo "";
                }
            ?>">
            <a class="nav-link"  href="http://drewincug.com"> Help </a>
            </li>
        </ul>
        

