 
    <style>
        /* Custom Styles for Navbar */
        .navbar {
            background-color: #343a40; /* Dark background for navbar */
            border-bottom: 1px solid #444;
        }

        .navbar-nav .nav-link {
            color: #ffffff;
            padding: 15px;
            font-size: 1rem;
            text-transform: capitalize;
        }

        .navbar-nav .nav-link:hover {
            background-color: #495057;
            color: #ffffff;
        }

        .navbar-nav .nav-item {
            position: relative;
        }

        .navbar-nav .nav-item .dropdown-menu {
            background-color: #343a40;
            border: none;
            min-width: 200px;
        }

        .navbar-nav .nav-item .dropdown-menu a {
            color: #ffffff;
        }

        .navbar-nav .nav-item .dropdown-menu a:hover {
            background-color: #495057;
        }

        .navbar-search-block {
            display: none; /* Hidden by default */
        }

        .navbar-search-block.active {
            display: block; /* Show when active */
        }

        .navbar-search-block .form-control-navbar {
            border-radius: 5px 0 0 5px;
        }

        .navbar-search-block .btn-navbar {
            border-radius: 0 5px 5px 0;
        }

        .navbar-search-block .btn-navbar i {
            color: #ffffff;
        }
    </style>
 
<nav class="main-header navbar navbar-expand navbar-dark">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button">
                <i class="fas fa-bars"></i>
            </a>
        </li> 
         <!-- Fullscreen Toggle -->
        <li class="nav-item">
            <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                <i class="fas fa-expand-arrows-alt"></i>
            </a>
        </li>
        
        <!-- Navbar Search -->
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

        <!-- Profile Dropdown -->
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-user-circle"></i> <span>Profile</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <a class="dropdown-item" href="profile.php">
                    <i class="fas fa-user"></i> My Profile
                </a>
                <a class="dropdown-item" href="settings.php">
                    <i class="fas fa-cogs"></i> Settings
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </li>

       

    </ul>
</nav>
c
<script>
    $(document).ready(function () {
        // Toggle search block visibility
        $('[data-widget="navbar-search"]').on('click', function () {
            $('.navbar-search-block').toggleClass('active');
        });
    });
</script>c