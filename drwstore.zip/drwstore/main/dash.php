<!-- Info boxes -->
<div class="row">
  <!-- Dashboard -->
  <div class="col-12 col-sm-6 col-md-4">
    <a href="home.php?tag=dash">
      <div class="info-box">
        <span class="info-box-icon bg-primary elevation-1"><i class="fas fa-home"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Dashboard</span>
          <span class="info-box-number">Overview</span>
        </div>
      </div>
    </a>
  </div>

  <!-- Sales -->
  <div class="col-12 col-sm-6 col-md-4">
    <a href="home.php?tag=sales&sinv_no=<?php echo 'DRS-'.rand(1,99999); ?>">
      <div class="info-box">
        <span class="info-box-icon bg-info elevation-1"><i class="fas fa-cash-register"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Sales</span>
          <span class="info-box-number">
           
          </span>
        </div>
      </div>
    </a>
  </div>

  <!-- Products -->
  <div class="col-12 col-sm-6 col-md-4">
    <a href="home.php?tag=prods">
      <div class="info-box">
        <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-archive"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Products</span>
          <span class="info-box-number">
             
          </span>
        </div>
      </div>
    </a>
  </div>

  <!-- Other Services -->
  <div class="col-12 col-sm-6 col-md-4">
    <a href="home.php?tag=mm">
      <div class="info-box">
        <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-concierge-bell"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Other Services</span>
          <span class="info-box-number">Multiple</span>
        </div>
      </div>
    </a>
  </div>

  <!-- Reports -->
  <div class="col-12 col-sm-6 col-md-4">
    <a href="home.php?tag=rpt">
      <div class="info-box">
        <span class="info-box-icon bg-success elevation-1"><i class="fas fa-clipboard-list"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Reports</span>
          <span class="info-box-number">Detailed Analysis</span>
        </div>
      </div>
    </a>
  </div>

  <!-- Settings -->
  <div class="col-12 col-sm-6 col-md-4">
    <a href="home.php?tag=set">
      <div class="info-box">
        <span class="info-box-icon bg-secondary elevation-1"><i class="fas fa-tools"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Settings</span>
          <span class="info-box-number">Configuration</span>
        </div>
      </div>
    </a>
  </div>
</div>

<style>
  /* Custom styles for Info Boxes */
  .info-box {
    transition: transform 0.3s, box-shadow 0.3s;
    border-radius: 0.25rem;
  }

  .info-box:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12), 0 6px 6px rgba(0, 0, 0, 0.16);
  }

  .info-box-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 0.25rem 0 0 0.25rem;
  }

  .info-box-content {
    padding-left: 15px;
  }

  .info-box-text {
    font-size: 1.1rem;
    font-weight: bold;
  }

  .info-box-number {
    font-size: 1.5rem;
    font-weight: bold;
  }

  .info-box-link {
    text-decoration: none;
    color: inherit;
  }
</style>
