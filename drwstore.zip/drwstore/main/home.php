<?php 
        // Enable error reporting
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
        
        
session_save_path('/tmp');
   include('../includes/auth.php');
    
    
    include('../includes/connect.php');  
?>   
<?php 
$d=date('d');
$m=date('n');
$y= date('y');
$h= date('H');
$min= date('i');
$inv_no='DRINV'.$d.$m.$y.$h.$min;
?>
<?php
    $tag="";
    if (isset($_GET['tag'])) {
        $tag=$_GET['tag'];
    }
?>





<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>DREWPOS|<?php echo $tag;?></title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
</head>
<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div class="wrapper">

  <!-- Preloader 
  <div class="preloader flex-column justify-content-center align-items-center"> 
    <img class="animation__wobble" src="../drewpos.png" alt="DREWPOS" height="60" width="60">
  </div>
-->
  <!-- Navbar -->
  <?php 

  ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
   <?php
          include("includes/topnav.php");
          include("includes/aside.php");

          ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

       <?php
          include("includes/titlebar.php");

          ?>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <?php
           if ($tag=="dash" or $tag=="") {
              include("dash.php");
           }elseif ($tag=="sales") { 
               include("sales/sales.php"); 
           }elseif ($tag=="salesres") { 
               include("sales/salesres.php"); 
           }elseif ($tag=="dsale") { 
               include("sales/dsale.php"); 
           }elseif ($tag=="csale") { 
               include("sales/csale.php"); 
           }elseif ($tag=="bout") { 
               include("sales/bout.php"); 
           }elseif ($tag=="rcpt") { 
               include("sales/rcpt.php"); 
           }elseif ($tag=="srepdash") { 
                include("includes/srepnav.php");
               include("sales/rep/srepdash.php"); 
           }elseif ($tag=="srep") { 
                include("includes/srepnav.php");
               include("sales/rep/srep.php"); 
           }


 
           elseif ($tag=="srcpt") { 
                //include("includes/incnav.php");
               include("sales/srcpt.php"); 
           }elseif ($tag=="inc") { 
                include("includes/incnav.php");
               include("inc/inc.php"); 
           }elseif ($tag=="inccat") { 
                include("includes/incnav.php");
               include("inc/inccat.php"); 
           }
           



           elseif ($tag=="exp") { 
                include("includes/expnav.php");
               include("exp/exp.php"); 
           }elseif ($tag=="addexp") { 
                include("includes/expnav.php");
               include("exp/addexp.php"); 
           }elseif ($tag=="expcat") { 
                include("includes/expnav.php");
               include("exp/expcat.php"); 
           }


           elseif ($tag=="tec") { 
                include("includes/tecnav.php");
               include("tec/tec.php"); 
           }elseif ($tag=="pendtec") { 
                include("includes/tecnav.php");
               include("tec/pendtec.php"); 
           }elseif ($tag=="addtec") { 
                include("includes/tecnav.php");
               include("tec/addtec.php"); 
           }

           elseif ($tag=="set") { 
                include("includes/setnav.php");
               include("set/settings.php"); 
           }elseif ($tag=="addacc") { 
                include("includes/setnav.php");
               include("set/addacc.php"); 
           }elseif ($tag=="vacc") { 
                include("includes/setnav.php");
               include("set/vacc.php"); 
           }elseif ($tag=="accset") { 
                include("includes/setnav.php");
               include("set/accset.php"); 
           }elseif ($tag=="user") { 
                include("includes/setnav.php");
               include("set/user.php"); 
           }elseif ($tag=="o_set") { 
                include("includes/setnav.php");
               include("set/o_set.php"); 
           }elseif ($tag=="comp_det") { 
                include("includes/setnav.php");
               include("set/comp_det.php"); 
           }elseif ($tag=="comp_bra") { 
                include("includes/setnav.php");
               include("set/comp_bra.php"); 
           }

           //policy  comp_set
           elseif ($tag=="pol") { 
                include("includes/setnav.php");
               include("includes/pol.php"); 
           } 

           elseif ($tag=="mm") { 
                //include("includes/mmnav.php");
               include("mm/mm.php"); 
           }elseif ($tag=="addmm") { 
                //include("mm/otnavbar.php");
               include("mm/addmm.php"); 
           }elseif ($tag=="addmmdet") { 
                include("includes/mmnav.php");
               include("mm/addmmdet.php"); 
           }elseif ($tag=="mmtrid") { 
                include("includes/mmnav.php");
               include("mm/mmtrid.php"); 
           }elseif ($tag=="mmrpt") { 
                //include("includes/mmnav.php");
               include("mm/mmrpt1.php"); 
           }


           elseif ($tag=="delprods") { 
               include("includes/sale/delprodso.php"); 
           }elseif ($tag=="schkout") { 
               include("includes/sale/schkout.php"); 
           }elseif ($tag=="recpt") { 
               include("includes/sale/recpt.php"); 
           }elseif ($tag=="sprod") { 
               include("includes/sale/sprod.php"); 
           }elseif ($tag=="custform") { 
               include("includes/sale/custform.php"); 
           }

           elseif ($tag=="prods") {
                include("includes/prodnav.php");
                include("prods/prods.php");
           }elseif ($tag=="addprods") {
                include("includes/prodnav.php");
                include("prods/addprods.php");
           } elseif ($tag=="abprods") {
                include("includes/prodnav.php");
                include("prods/abprods.php");
           }elseif ($tag=="apay") {
                include("includes/prodnav.php");
                include("prods/apay.php");
           }elseif ($tag=="apaym") {
                include("includes/prodnav.php");
                include("prods/apaym.php");
           }elseif ($tag=="posk") {
                include("includes/prodnav.php");
                include("prods/posk.php");
           }elseif ($tag=="delcat") { 
                include("includes/prod/delcat.php");
           }elseif ($tag=="psup") {
                include("includes/prodnav.php");
                include("prods/psup.php");
           }elseif ($tag=="vbch") { 
                include("includes/prodnav.php");
                include("prods/vbch.php");
           }elseif ($tag=="posk") {
                include("includes/prodnav.php");
                include("posk.php");
           }


           elseif ($tag=="cats") {  
                include("includes/prodnav.php");
                include("cats/cat.php");
           }elseif ($tag=="cathome") {  
                include("includes/prodnav.php");
                include("cats/cat.php");
           }elseif ($tag=="subcat") {  
                include("includes/prodnav.php");
                include("cats/subcat.php");
           }elseif ($tag=="rptcat") {  
                include("includes/prodnav.php");
                include("cats/rptcat.php");
           }


           elseif ($tag=="sups") {  
                include("includes/prodnav.php");
                include("sup/sup.php");
           }


           elseif ($tag=="addprodsupplied") {  
                include("includes/prod/addbanchprod.php");
           }elseif ($tag=="addbanchprod") {  
                include("includes/prodnav.php");
                include("includes/prod/addbanchprod.php");
           }elseif ($tag=="ceckprodsup") {  
                include("includes/prod/ceckprodsup.php");
           }elseif ($tag=="ats") {  
                include("includes/prod/ats.php");
           }elseif ($tag=="apts") {  
                include("includes/prod/apts.php");
           }elseif ($tag=="dpfb") {  
                include("includes/prod/dpfb.php");
           }
           
//reports  vpsale
           elseif ($tag=="rpt") {  
                include("includes/rptnav.php");
                include("rpt/rpt.php");
           }elseif ($tag=="fsrpt") { 
                include("includes/rptnav.php"); 
                include("rpt/fsrpt.php");
           }elseif ($tag=="pdsale") { 
                include("includes/rptnav.php"); 
                include("rpt/pdsale.php");
           }elseif ($tag=="psale") { 
                include("includes/rptnav.php"); 
                include("rpt/psale.php");
           }elseif ($tag=="vpsale") { 
                include("includes/rptnav.php"); 
                include("rpt/vpsale.php");
           }elseif ($tag=="lsprep") { 
                include("includes/rptnav.php"); 
                include("rpt/lsprep.php");
           }elseif ($tag=="lsprorpt") { 
                include("includes/rptnav.php"); 
                include("rpt/lsprorpt.php");
           }

//balace sheet
           elseif ($tag=="blsheet") { 
                include("includes/rptnav.php"); 
                include("rpt/blsheet.php");
           }
//profit and loss  sheet incrpt
           elseif ($tag=="cfsrpt") { 
                include("includes/rptnav.php"); 
                include("rpt/cfsrpt.php");
           }

            elseif ($tag=="incrpt") { 
                include("includes/rptnav.php"); 
                include("rpt/incrpt.php");
           }
//rptstk
           elseif ($tag=="stkrpt") { 
                include("includes/rptnav.php"); 
                include("rpt/stkrpt.php");
           }elseif ($tag=="pdstk") { 
                include("includes/rptnav.php"); 
                include("rpt/pdstk.php");
           }elseif ($tag=="pbanch") { 
                include("includes/rptnav.php");  
                include("rpt/pbanch.php");
           }elseif ($tag=="rptsppi") { 
                include("includes/reports/rpnav.php"); 
                include("includes/reports/vsales.php");
           }elseif ($tag=="rptsspi") { 
                include("includes/reports/rpnav.php"); 
                include("includes/reports/vsales.php");
           }elseif ($tag=="rptsspp") { 
                include("includes/reports/rpnav.php"); 
                include("includes/reports/vsales.php");
           }elseif ($tag=="vsales") { 
                include("includes/reports/rpnav.php"); 
                include("includes/reports/vsales.php");
           }


// reportsmains
           elseif ($tag=="rpts") { 
                include("includes/reports/rpnav.php"); 
                include("includes/reports/spi.php");
           }elseif ($tag=="rptsslr") { 
                include("includes/reports/rpnav.php"); 
                include("includes/reports/rptsslr.php");
           }elseif ($tag=="rptsstk") { 
                include("includes/reports/rpnav.php"); 
                include("includes/reports/rptsstk.php");
           }elseif ($tag=="rptsbs") { 
                include("includes/reports/rpnav.php"); 
                include("includes/reports/rptsbs.php");
           }elseif ($tag=="rptspal") { 
                include("includes/reports/rpnav.php"); 
                include("includes/reports/rptspal.php");
           }elseif ($tag=="supplier") { 
                include("supplier.php");
           } elseif ($tag=="salesreport") {
                   
                include("salesreport.php");
           } elseif ($tag=="users") {    
                include("users.php");
           }elseif ($tag=="deluser") { 
               include("includes/user/deluser.php"); 
           }

           elseif ($tag=="profile") { 
               include("includes/user/profile.php"); 
           }

           elseif ($tag=="oser") { 
               include("set/oser.php"); 
           }



//employee
           elseif ($tag=="emp") { 
                include("includes/empnav.php"); 
               include("emp/emp.php"); 
           }elseif ($tag=="addemp") { 
                include("includes/empnav.php"); 
               include("emp/addemp.php"); 
           }elseif ($tag=="payroll") { 
                include("includes/empnav.php"); 
               include("emp/payroll.php"); 
           }


           elseif ($tag=="set") { 
               include("setting.php"); 
           } else{
            echo "page Not Found ";
           }
           ?>


   
      </div> 
    </section>

  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <?php include("../includes/footer.php");?>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="../plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.js"></script>

<!-- PAGE PLUGINS -->
<!-- jQuery Mapael -->
<script src="../plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
<script src="../plugins/raphael/raphael.min.js"></script>
<script src="../plugins/jquery-mapael/jquery.mapael.min.js"></script>
<script src="../plugins/jquery-mapael/maps/usa_states.min.js"></script>
<!-- ChartJS -->
<script src="../plugins/chart.js/Chart.min.js"></script>

<!-- AdminLTE for demo purposes --> 
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../dist/js/pages/dashboard2.js"></script>
</body>
</html>
