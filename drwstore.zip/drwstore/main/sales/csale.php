<?php
// Example error reporting and initialization
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include your database connection file
//include('../../includes/connect.php');

// Initialize variables (assuming $sinv_no and $price are already initialized)
echo $sinv_no = isset($_GET['sinv_no']) ? $_GET['sinv_no'] : '';
$price = isset($_GET['price']) ? $_GET['price'] : '';


// Fetch company details (define and fetch these variables from your database)
// Example: 
// $result = mysqli_query($conn, "SELECT * FROM company_details WHERE id=1");
// if ($row = mysqli_fetch_assoc($result)) {
//     $compname = $row['name'];
//     $compaddress = $row['address'];
//     $compphone1 = $row['phone1'];
//     $compphone2 = $row['phone2'];
//     $compwebsite = $row['website'];
//     $compemail = $row['email'];
// }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Receipt</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        .dark-mode input:-webkit-autofill,
        .dark-mode input:-webkit-autofill:focus,
        .dark-mode input:-webkit-autofill:hover,
        .dark-mode select:-webkit-autofill,
        .dark-mode select:-webkit-autofill:focus,
        .dark-mode select:-webkit-autofill:hover,
        .dark-mode textarea:-webkit-autofill,
        .dark-mode textarea:-webkit-autofill:focus,
        .dark-mode textarea:-webkit-autofill:hover {
            -webkit-text-fill-color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="invoice p-3 mb-3">
                    <!-- Title row -->
                    <div class="row">
                        <div class="col-12">
                            <h4>
                                <small class="float-right"><?php echo date("d M Y"); ?></small>
                            </h4>
                        </div>
                    </div>
                    <!-- Info row --> <br/>

                    <!-- Customer receipt table -->
                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table class="table table-hover text-nowrap">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Qty</th>
                                        <th>Cost Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                      $sss="SELECT * FROM `invoice_meta_tbl` WHERE invoice_code='$sinv_no'";
                                    $pcquery = mysqli_query($conn, "SELECT * FROM `invoice_meta_tbl` WHERE invoice_code='$sinv_no'") or die(mysqli_error($conn));
                                    while ($rowpc = mysqli_fetch_array($pcquery)) {
                                        $item = $rowpc['item'];
                                        $qty = $rowpc['qty'];
                                        $price = $rowpc['price'];
                                        $total = $rowpc['total'];
                                    ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($item); ?></td>
                                            <td><?php echo htmlspecialchars($qty); ?></td>
                                            <td><?php echo number_format($price); ?></td>
                                            <td><?php echo number_format($total); ?></td>
                                        </tr>
                                    <?php } ?>
                                    <tr class="alert alert-success">
                                        <td colspan="3">Total</td>
                                        <td><strong style="font-size: 20px;">
                                            <?php 
                                            $gettc = mysqli_query($conn, "SELECT SUM(total) as cost FROM `invoice_meta_tbl` WHERE invoice_code='$sinv_no'") or die(mysqli_error($conn));
                                            $cost = 0;
                                            while ($qgettc = mysqli_fetch_array($gettc)) {   
                                                $cost = $qgettc['cost'];
                                            }
                                             $cost;
                                            ?>
                                        </strong></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Customer details form -->
            <div class="col-md-7">
                <div class="card card-default">
                    <div class="card-header">
                        <center><h5>CUSTOMER DETAILS</h5></center>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Customer Name</label>
                                        <input type="text" class="form-control" name="cust_name" placeholder="Customer Name" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Customer Contact</label>
                                        <input type="text" class="form-control" name="cust_phone" placeholder="Customer Contact" required>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Amount Paid</label>
                                        <input type="text" class="form-control" name="amount_pay" placeholder="Amount Paid" required>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-primary btn-lg btn-block" name="bout" value="Submit">
                                    </div>
                                </div>
                            </div>
                        </form>

                        <?php
                        if (isset($_POST['bout'])) {
                            // Escape and sanitize input
                            $customer_name = mysqli_real_escape_string($conn, $_POST['cust_name']);
                            $cust_phone = mysqli_real_escape_string($conn, $_POST['cust_phone']);
                            $amount_pay = mysqli_real_escape_string($conn, $_POST['amount_pay']);
                            $total_amount = $cost; // Ensure $cost is set before use
                            $invoice_code = $sinv_no;

                            // Construct the SQL query
                            $query = "INSERT INTO invoices_tbl (id, invoice_code, customer, cust_phone, total_amount, tendered_amount, created_at, updated_at) 
                                      VALUES (NULL, '$invoice_code', '$customer_name', '$cust_phone', '$total_amount', '$amount_pay', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP())";

                            // Execute the query and check if successful
                            if (mysqli_query($conn, $query)) {
                                echo "<script>
                                        // Redirection after successful insertion
                                        window.location.href = 'home.php?tag=srcpt&sinv_no=$sinv_no';
                                      </script>";
                                exit; // Ensure no further code is executed
                            } else {
                                echo "Wrong Entry: " . mysqli_error($conn);
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
