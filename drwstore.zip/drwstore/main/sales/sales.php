<?php
 $sinv_no = isset($_GET['sinv_no']) ? $_GET['sinv_no'] : '';

// Query to fetch invoice details if needed based on sinv_no
// Example: $invoice_details = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM invoice_meta_tbl WHERE sinv_no='$sinv_no'"));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom Styles -->
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f8f9fa;
            padding: 10px;
        }

        .invoice {
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .invoice h5 {
            font-size: 18px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }

        .form-label {
            font-size: 14px;
            font-weight: bold;
        }

        .form-control {
            font-size: 14px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            font-size: 16px;
        }

        .product-item {
            margin-bottom: 15px;
            padding: 10px;
            background-color: #e9ecef;
            border-radius: 5px;
        }

        .product-item h3 {
            font-size: 16px;
            margin-bottom: 5px;
        }

        .product-item .price {
            font-size: 14px;
            color: #007bff;
            font-weight: bold;
        }

        .receipt-table th, .receipt-table td {
            font-size: 14px;
            text-align: center;
            padding: 8px;
        }

        .receipt-table .total {
            font-size: 16px;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .invoice {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 mb-4">
                <div class="invoice">
                    <h5>CUSTOMER RECEIPT</h5>
                    <form action="" method="POST">
                        <input type="hidden" id="invoice_m_code" value="<?php echo 'DRMdata'. rand(1,99999); ?>" name="invoice_m_code">
                        <input type="hidden" name="sinv_no" value="<?php echo $sinv_no; ?>">
 

                        <div class="form-group">
                            <label for="item" class="form-label">Item</label>
                            <input type="text" class="form-control" id="item" name="item" required>
                        </div>

                        <div class="form-group">
                            <label for="item_category" class="form-label">Item Category</label>
                            <input type="text" class="form-control" id="item_category" name="item_category" required>
                        </div>

                        <div class="form-row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="qty" class="form-label">Quantity</label>
                                    <input type="number" class="form-control" id="qty" name="qty" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="unit" class="form-label">Unit</label>
                                    <input type="text" class="form-control" id="unit" value="KG" name="unit" required>
                                </div>
                            </div>
                        </div> 

                        <div class="form-group">
                            <label for="price" class="form-label">Unit Price</label>
                            <input type="number" step="0.01" class="form-control" id="price" name="price" required>
                        </div>

                        <div class="form-group">
                            <label for="Description" class="form-label">Description</label>
                            <textarea placeholder="Description" class="form-control" name="note"></textarea>
                        </div>

                        <button type="submit" name="save" class="btn btn-success">Submit</button>
                    </form>
                </div>
            </div>
<?php
if (isset($_POST['save'])) {
    // Escape and sanitize input
    $invoice_m_code = mysqli_real_escape_string($conn, $_POST['invoice_m_code']);
    $invoice_code = $sinv_no; // Assuming $sinv_no is defined elsewhere
    //$customer_name = mysqli_real_escape_string($conn, $_POST['customer_name']);
    $item = mysqli_real_escape_string($conn, $_POST['item']);
    $item_category = mysqli_real_escape_string($conn, $_POST['item_category']);
    $qty = mysqli_real_escape_string($conn, $_POST['qty']);
    $unit = mysqli_real_escape_string($conn, $_POST['unit']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $note = mysqli_real_escape_string($conn, $_POST['notes']);

    // Calculate total cost
    $total_cost = $price * $qty;

    // Construct the SQL query
    $query = "INSERT INTO invoice_meta_tbl (id, invoice_m_code, invoice_code, item, item_category, qty, unit, price, notes, total, date_added) 
              VALUES (NULL, '$invoice_m_code', '$invoice_code', '$item', '$item_category', '$qty', '$unit', '$price', '$note', '$total_cost', CURRENT_TIMESTAMP())";

    // Execute the query and check if successful
    if (mysqli_query($conn, $query)) {
        // Debugging output (optional)
        echo "<script>
                // Redirection after successful insertion
                window.location.href = 'home.php?tag=sales&sinv_no=$sinv_no';
              </script>";
        exit; // Ensure no further code is executed
    } else {
        // Handle the error
        echo "Wrong Entry: " . mysqli_error($conn);
    }
}

?>
            <div class="col-12">
                <div class="invoice">
                    <div class="receipt-table">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>#Code </th>
                                    <th>Item </th>
                                    <th>Qty</th>
                                    <th>Cost Price</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $pcquery = mysqli_query($conn, "SELECT * FROM `invoice_meta_tbl` WHERE invoice_code='$sinv_no'") or die(mysqli_error($conn));
        //id  invoice_m_code  invoice_code    item    item_category   price   qty     unit    total   notes   date_added
                                    while ($rowpc = mysqli_fetch_array($pcquery)) {
                                        $invoice_m_code = $rowpc['invoice_m_code'];
                                        $invoice_code = $rowpc['invoice_code'];
                                        $item = $rowpc['item']; 
                                        $item_category = $rowpc['item_category'];
                                        $price = $rowpc['price'];
                                        $qty = $rowpc['qty'];
                                        $unit = $rowpc['unit'];
                                        $total = $rowpc['total'];
                                        $notes = $rowpc['notes'];
                                        $date_added = $rowpc['date_added'];
                                ?>
                                <tr>
                                    <td><?php echo $rowpc['invoice_m_code']; ?></td>
                                    <td><?php echo $rowpc['item']; ?> ( <?php echo $rowpc['item_category']; ?>)</td>
                                    <td><?php echo $rowpc['qty']; ?>  <?php echo $rowpc['unit']; ?></td>
                                    <td><?php echo isset($price) ? number_format($price) : '0'; ?></td>
                                    <td><?php echo isset($total) ? number_format($total) : '0'; ?></td>
                                    <td>
                                        <a href="home.php?tag=dsale&so_id=<?php echo $vv; ?>&sinv_no=<?php echo $sinv_no; ?>" class="btn btn-danger btn-sm">
                                            <i class="fa fa-trash"></i>  
                                        </a>
                                    </td>
                                </tr>
                                <?php } ?>
                                <tr>
                                    <td colspan="3"><strong>Total</strong></td>
                                    <td colspan="2"><strong class="total">
                                        <?php 
                                            $gettc = mysqli_query($conn, "SELECT SUM(total) as cost FROM `invoice_meta_tbl` WHERE invoice_code='$sinv_no'") or die(mysqli_error($conn));
                                            $cost = 0;
                                            while ($qgettc = mysqli_fetch_array($gettc)) {   
                                                $cost = $qgettc['cost'];
                                                echo isset($cost) ? number_format($cost) : '0';
                                            }
                                        ?>
                                    </strong></td>
                                </tr>
                            </tbody>
                        </table>
                        <a href="home.php?tag=csale&sinv_no=<?php echo $sinv_no; ?>" class="btn btn-primary">
                            Check Out <i class="fa fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
