<?php
// Example error reporting and initialization
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include your database connection file
// include('../../includes/connect.php');

// Initialize variables (assuming $sinv_no is already initialized)
$sinv_no = isset($_GET['sinv_no']) ? $_GET['sinv_no'] : '';

// Company details
$compname = 'CEAZAR GENERAL PRODUCE';
$compdealers = 'Dealers in: Rice Supply, Maize & Beans';
$compaddress = 'Shop No. HC19 & HD02 (HO83)';
$complocation = 'Nakayiza Arcade Mengo Kisenyi Kampala';
$compphone1 = '0773 444352';
$compphone2 = '0705 173179';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Receipt</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .invoice {
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .invoice h5 {
            font-size: 18px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }
        .invoice .company-details {
            margin-bottom: 20px;
        }
        .invoice .company-details p {
            margin: 0;
            font-size: 14px;
        }
        .table th, .table td {
            font-size: 14px;
            text-align: center;
            padding: 8px;
        }
        .table .total {
            font-size: 16px;
            font-weight: bold;
        }
        @media (max-width: 768px) {
            .invoice {
                padding: 10px;
            }
        }
        .print-btn {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="invoice">
                    <h5>CUSTOMER RECEIPT</h5>
                    
                    <!-- Company Details -->
                    <div class="company-details">
                        <p><strong><?php echo htmlspecialchars($compname); ?></strong></p>
                        <p><?php echo htmlspecialchars($compdealers); ?></p>
                        <p><?php echo htmlspecialchars($compaddress); ?></p>
                        <p><?php echo htmlspecialchars($complocation); ?></p>
                        <p>Tel: <?php echo htmlspecialchars($compphone1); ?>, <?php echo htmlspecialchars($compphone2); ?></p>
                    </div>

                    <!-- Invoice Number -->
                    <div class="mb-4">
                        <h6><strong>Invoice Number:</strong> <?php echo htmlspecialchars($sinv_no); ?></h6>
                    </div>

                    <!-- Display receipt -->
                    <div class="mt-4">
                        <h5>Invoice Details</h5>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Qty</th>
                                    <th>Cost Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $pcquery = mysqli_query($conn, "SELECT * FROM `invoice_meta_tbl` WHERE invoice_code='$sinv_no'") or die(mysqli_error($conn));
                                $total_amount = 0;
                                while ($rowpc = mysqli_fetch_array($pcquery)) {
                                    $item = $rowpc['item'];
                                    $qty = $rowpc['qty'];
                                    $price = $rowpc['price'];
                                    $total = $rowpc['total'];
                                    $total_amount += $total;
                                ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item); ?></td>
                                        <td><?php echo htmlspecialchars($qty); ?></td>
                                        <td><?php echo number_format($price, 2); ?></td>
                                        <td><?php echo number_format($total, 2); ?></td>
                                    </tr>
                                <?php } ?>
                                <tr class="alert alert-success">
                                    <td colspan="3">Total</td>
                                    <td><strong class="total"><?php echo number_format($total_amount, 2); ?></strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Print button -->
                    <button class="print-btn" onclick="printReceipt()">Print Receipt</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        function printReceipt() {
            // Open a new window for printing
            const printWindow = window.open('', '', 'height=600,width=800');
            
            // Insert the receipt content here
            printWindow.document.write('<html><head><title>Receipt</title>');
            printWindow.document.write('</head><body >');
            printWindow.document.write(document.querySelector('.invoice').innerHTML);
            printWindow.document.write('</body></html>');
            
            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
        }
    </script>
</body>
</html>
