<?php    
 $so_id=$_GET['so_id'];
 $sinv_no=$_GET['sinv_no'];
 $delsale= "DELETE FROM `sales_order` WHERE `sales_order`.`sales_order_id` = '$so_id';";
$qdelsale=mysqli_query($conn, $delsale);
if ($qdelsale) {

?>
	 <script type="text/javascript">
               window.location.href='home.php?tag=sales&sinv_no=<?php echo $sinv_no ?>';
            </script><?php
}else{
	echo "No Item Deleted";
}
?> 