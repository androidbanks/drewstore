<?php 

 
echo$sinv_no= $_GET['sinv_no'];
echo$price=$_GET['price'];
echo$pro=$_GET['pro'];

echo $sinv_no= $sinv_no;
echo$cust_name= $_POST['cust_name'];
echo$cust_phone= $_POST['cust_phone'];
echo$cashier= $mem_name;
 echo $amount_pay= $_POST['amount_pay'];
echo$amount_cost= $price;
echo$profit= $pro; 
echo $bal=$amount_pay-$amount_cost;
 
   echo $soqry = "INSERT INTO `sales` (`sales_id`,`sinv_no`,`cust_name`,`cust_phone`,`cashier`,`amount_pay`,`amount_cost`,`profit`,`bal`,`date_added`) VALUES (NULL,'$sinv_no','$cust_name','$cust_phone','$cashier','$amount_pay','$amount_cost','$profit','$bal', current_timestamp());";
       $soq = mysqli_query($conn, $soqry);
       if ($soq) { 
       echo $incinv_no =$sinv_no;
       echo $code='DR-'.rand(1,99999); 
       $name='Merchandise Sales';
       $amount=$pro; 
       $user=$mem_name; 
       echo $addinc = "INSERT INTO `income` (`income_id`,`code`,`name`,`amount`,`user`,`incinv_no`,`date_added`) VALUES (NULL,'$code','$name','$amount','$user','$incinv_no', current_timestamp());";
       $qaddinc = mysqli_query($conn, $addinc);
       if ($addinc) {  

        ?>
        <script type="text/javascript">
          window.location.href='home.php?tag=rcpt&sinv=<?php echo $bscode; ?>';
        </script>
        <?php
       }
               
       }


 ?>