<?php
	if(ISSET($_POST['search'])){
		$keyword = $_POST['keyword'];
?>
<div>
	<h3>Products Result</h3>
	<hr style="border-top:2px dotted #ccc;"/>
	<?php
		require 'connect.php';
		$query = mysqli_query($conn, "SELECT * FROM `products` WHERE `prod_code` LIKE '%$keyword%' or `prod_name` LIKE '%$keyword%' ORDER BY `prod_name`") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
			$prod_id=$fetch['prod_id'];
	?>
	<div class="alert alert-info" style="word-wrap:break-word;">
		<div class="row">
			<div class="col-md-9">
				<h4><?php echo $fetch['prod_code']?>
				<?php echo $fetch['prod_name']?></h4>
			</div>
			<div class="col-md-3">
				<h4><?php echo '@'. substr($fetch['price_each'], 0, 100)?></h4>
			</div>
		</div>
		<form method="POST" action="incoming.php">
		<div class="row">
			<div class="col-md-5">
				<div class="form-group">
					<input type="hidden"  value="<?php echo $prod_id ?>" name="prod_id">
					<input type="hidden" value="<?php echo $_GET['inv_no'] ?>" name="inv_no">
					<input type="text" placeholder="Enter Price " class="form-control" name="psprice">
				</div>
			</div> 
			<div class="col-md-3">
				<div class="form-group">
					<input type="text" placeholder="QTY" class="form-control" name="qty">
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<input class="btn btn-primary" value="add"   type="submit" name="add">
				</div>
			</div>
		</div> 
		</form>

	</div> 
	<?php
		}
	?>
</div>
<?php
	}
?>