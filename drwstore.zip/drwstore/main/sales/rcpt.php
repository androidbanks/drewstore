<style type="text/css"> 
  @media print {
    @page {
      size: auto; /* auto is the default value */
      margin: 0; /* zero out the margins */
    }

    /* Disabling headers and footers */
    @page :first {
      margin-top: 0;
    }

    @page {
      margin-bottom: 0;
    }
  }

  .dark-mode input:-webkit-autofill,
  .dark-mode input:-webkit-autofill:focus,
  .dark-mode input:-webkit-autofill:hover,
  .dark-mode select:-webkit-autofill,
  .dark-mode select:-webkit-autofill:focus,
  .dark-mode select:-webkit-autofill:hover,
  .dark-mode textarea:-webkit-autofill,
  .dark-mode textarea:-webkit-autofill:focus,
  .dark-mode textarea:-webkit-autofill:hover {
    -webkit-text-fill-color: #6c757d;
  }
</style>

<?php 
  $sinv_no = $_GET['sinv_no']; 
  $getcomp = mysqli_query($conn,"SELECT * FROM `comp_det` ") or die(mysqli_error($conn));
  for($i=1; $qgetcomp = mysqli_fetch_array($getcomp); $i++){   
    $compname = $qgetcomp['name']; 
    $compcode = $qgetcomp['code'];
    $compaddress = $qgetcomp['address']; 
    $compphone1 = $qgetcomp['phone1']; 
    $compphone2 = $qgetcomp['phone2']; 
    $compwebsite = $qgetcomp['website']; 
    $compemail = $qgetcomp['email']; 
    $compdescription = $qgetcomp['description']; 
  }  
?> 

<?php   
  $sinv_no = $_GET['sinv_no'];
  $price = $_GET['price'];
  
  $gsales = mysqli_query($conn,"SELECT * FROM `sales` WHERE sinv_no='$sinv_no' ") or die(mysqli_error($conn)); 
  for($i=1; $qgsales = mysqli_fetch_array($gsales); $i++){ 
    $sales_id = $qgsales['sales_id'];
    $sinv_no = $qgsales['sinv_no'];
    $cust_name = $qgsales['cust_name'];
    $cust_phone = $qgsales['cust_phone'];
    $cashier = $qgsales['cashier'];
    $amount_pay = $qgsales['amount_pay'];
    $amount_cost = $qgsales['amount_cost'];
    $profit = $qgsales['profit'];
    $bal = $qgsales['bal'];
    $date_added = $qgsales['date_added'];  
  }  
?>

<div class="row">
  <div class="col-12">
    <div class="invoice p-3 mb-3">
      <!-- title row -->
      <div class="row">
        <div class="col-12">
          <h4> 
            <small class="float-right"><?php echo date("d M Y")?></small>
          </h4>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-5 invoice-col"> 
        </div> 
        <div class="col-sm-4 invoice-col">
          <img width="80" height="80" src="../drewpos.png" alt="AdminLTE Logo" class="brand-image img-rounded" style="float: right;">   
        </div> 
        <!-- /.col -->
        <div class="col-sm-3 invoice-col"> 
        </div> 
        <!-- /.col -->
      </div>
      <div class="row invoice-info"> 
        <div class="col-sm-5 invoice-col">  
        </div> 
        <div class="col-sm-3 invoice-col"> 
        </div> 
        <!-- /.col -->
        <div class="col-sm-4 invoice-col"> 
          <address>
            <strong style="font-size:30px; text-transform:uppercase;"><?php echo $compname;?> </strong>
            <p style="font-size:16px; text-transform:capitalize;">
              <?php echo $compaddress;?><br>  
              <?php echo $compphone1;?> / <?php echo $compphone2;?><br>
              <?php echo $compwebsite;?><br>
              <?php echo $compemail;?>
            </p>
          </address>
        </div> 
        <!-- /.col -->
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <!-- /.col -->
        <div class="col-sm-7 invoice-col">
          <address>
            <strong>Invoice : #<?php echo $sinv_no   ?> </strong><br>
            <strong>Bill To</strong><br>
            <strong>CUSTOMER NAME: <?php echo $cust_name   ?> </strong><br>
            <strong>CUSTOMER Phone No: <?php echo $cust_phone   ?> </strong><br> 
          </address>
        </div> 
        <!-- /.col -->
        <div class="col-sm-5 invoice-col"> 
        </div> 
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <center> 
        <h5>CUSTOMER RECEIPT</h5>
      </center>
      <!-- Table row -->
      <div class="row">
        <div class="col-12 table-responsive">
          <table class="table table-hover text-nowrap">
            <thead>
              <tr> 
                <th>Name</th> 
                <th>Qty</th>
                <th>Cost Price</th> 
                <th>Total</th>     
              </tr>
            </thead>
            <tbody>
              <?php  
                $pcquery = mysqli_query($conn,"SELECT * FROM `sales_order` WHERE sinv_no='$sinv_no';  ") or die(mysqli_error($conn));
                while ($rowpc = mysqli_fetch_array($pcquery)) {
                  $vv = $rowpc['sales_order_id'];
                  $a_price = $rowpc['a_price'];
                  $sxqty = $rowpc['sqty']; 
                  $t_cost = $rowpc['t_cost'];  
              ?> 
              <tr>   
                <td style="text-transform: capitalize;"><?php echo $rowpc['prod_name']; ?></td> 
                <td><?php echo $rowpc['sqty']; ?></td> 
                <td><?php echo number_format($a_price); ?></td>
                <td><?php echo number_format($t_cost); ?></td>  
              </tr>
              <?php } ?>
              <?php  
                $gettc = mysqli_query($conn,"SELECT *, SUM(t_cost) as cost ,SUM(c_profit) as pro FROM `sales_order` WHERE sinv_no='$sinv_no'") or die(mysqli_error($conn));
                for($i=1; $qgettc = mysqli_fetch_array($gettc); $i++){   
                  $cost = $qgettc['cost'];
                  $pro = $qgettc['pro'];
                  number_format($cost);
                } 
              ?> 
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <!-- accepted payments column -->
        <div class="col-6">
          <p class="lead">Payment Methods:</p>
          <img src="../../dist/img/credit/visa.png" alt="Visa">
          <img src="../../dist/img/credit/mastercard.png" alt="Mastercard">
          <img src="../../dist/img/credit/american-express.png" alt="American Express">
          <img src="../../dist/img/credit/paypal2.png" alt="Paypal">
          <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
            Goods once Sold are not returnable  
          </p>
        </div>
        <!-- /.col -->
        <div class="col-6"> 
          <div class="table-responsive">
            <table class="table">
              <tr>
                <th style="width:50%">Total Product Cost:</th>
                <td>UGX <?php echo number_format($amount_cost);?></td>
              </tr> 
              <tr>
                <th style="width:50%">Amount given:</th>
                <td>UGX <?php echo number_format($amount_pay);?></td>
              </tr> 
              <tr>
                <th>Balance:</th>
                <td>UGX <?php echo number_format($bal);?></td>
              </tr> 
            </table>
          </div>
        </div>
        <!-- /.col -->
      </div>

      <div class="row no-print">
        <div class="col-12">  
          <button type="button" onclick="window.print()" name="printout" class="btn btn-primary float-right" style="margin-right: 5px;">
            <i class="fas fa-download"></i> Print Receipt
          </button>
          <button type="button" onclick="printThermal()" name="printThermal" class="btn btn-success float-right" style="margin-right: 5px;">
            <i class="fas fa-print"></i> Print Thermal
          </button>
        </div>
      </div>
    </div>
  </div>
</div> 

<script>
  function printThermal() {
    var printContents = document.querySelector('.invoice').innerHTML;
    var popupWin = window.open('', '_blank', 'width=300,height=400');
    popupWin.document.open();
    popupWin.document.write(`
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; }
            .invoice { width: 250px; margin: 0 auto; }
            /* Add additional styles for your thermal printer layout */
          </style>
        </head>
        <body onload="window.print(); window.close();">
          <div class="invoice">
            ${printContents}
          </div>
        </body>
      </html>
    `);
    popupWin.document.close();
  }
</script>
