<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include your database connection file
include('../../includes/connect.php');

try {
    // Initialize variables from POST and GET requests
    $sinv_no = isset($_GET['sinv_no']) ? mysqli_real_escape_string($conn, $_GET['sinv_no']) : '';
    $price = isset($_GET['price']) ? floatval($_GET['price']) : 0;
    $pro = isset($_GET['pro']) ? floatval($_GET['pro']) : 0;

    // Validate input and calculate necessary variables
    $cust_name = isset($_POST['cust_name']) ? mysqli_real_escape_string($conn, $_POST['cust_name']) : '';
    $cust_phone = isset($_POST['cust_phone']) ? mysqli_real_escape_string($conn, $_POST['cust_phone']) : '';
    $amount_pay = isset($_POST['amount_pay']) ? floatval($_POST['amount_pay']) : 0;
    $cashier = isset($mem_name) ? mysqli_real_escape_string($conn, $mem_name) : '';

    // Calculate profit and balance
    $amount_cost = $price;
    $profit = is_numeric($pro) ? $pro : 0;
    $bal = $amount_pay - $amount_cost;

    // Insert into sales table
    $stmt = $conn->prepare("INSERT INTO sales (sales_id, sinv_no, cust_name, cust_phone, cashier, amount_pay, amount_cost, profit, bal, date_added) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
    $stmt->bind_param("sssdddddd", $sinv_no, $cust_name, $cust_phone, $cashier, $amount_pay, $amount_cost, $profit, $bal);
    if (!$stmt->execute()) {
        throw new Exception("Error inserting sales record: " . $stmt->error);
    }
    $stmt->close();

    // Insert into income table
    $stmt = $conn->prepare("INSERT INTO income (income_id, code, name, inc_type, amount, user, date_added) VALUES (NULL, ?, 'Merchandise Sales', 'Sales', ?, ?, CURRENT_TIMESTAMP)");
    $stmt->bind_param("ssd", $sinv_no, $profit, $cashier);
    if (!$stmt->execute()) {
        throw new Exception("Error inserting income record: " . $stmt->error);
    }
    $stmt->close();

    // Redirect to home.php
    header("Location: home.php?tag=rcpt&sinv_no=" . urlencode($sinv_no) . "&price=" . urlencode($price));
    exit();

} catch (Exception $e) {
    echo "Caught exception: " . htmlspecialchars($e->getMessage());
}
?>
